/**
 * Office Pet - License 授权模块（在线校验版）
 *
 * 授权流程：
 * 1. 首次安装自动记录安装时间，享有 7 天免费试用（本地 + 服务端双重记录）
 * 2. 第 8 天起需要有效 License 才能启动
 * 3. 用户运行 `scripts/fingerprint.sh` 获取机器指纹
 * 4. 管理员通过 License Server 颁发 License Key
 * 5. 用户通过 API 或手动写入激活 License
 * 6. 启动时向 License Server 在线校验；每 4 小时心跳续验
 * 7. 离线时可降级为本地缓存校验（缓存有效期 72 小时）
 *
 * 安全设计：
 * - 客户端不持有任何签名密钥
 * - License Key 由服务端生成（crypto.randomBytes），无法本地伪造
 * - 校验逻辑在服务端完成，客户端只接收 valid/invalid 结果
 * - 服务端可随时吊销 License，下次客户端校验即失效
 * - 离线缓存 72 小时后强制要求在线校验
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const { execSync } = require('child_process');

const STATS_DIR = path.join(os.homedir(), '.office-pet-stats');
const LICENSE_FILE = path.join(STATS_DIR, 'license.json');
const CACHE_FILE = path.join(STATS_DIR, '.license-cache.json');
const META_FILE = path.join(STATS_DIR, '.install-meta.json');
const TRIAL_DAYS = 7;
const HEARTBEAT_INTERVAL = 4 * 60 * 60 * 1000; // 4 小时
const OFFLINE_GRACE_HOURS = 72; // 离线宽限 72 小时

// License Server 地址（可通过环境变量覆盖）
// 默认使用 HTTPS + 自签证书；本地开发可设为 http://127.0.0.1:13122
const LICENSE_SERVER = process.env.LICENSE_SERVER || 'https://123.207.44.191';

// ── 自签证书 CA 加载 ─────────────────────────────────────────────────
// 证书文件查找顺序：
//   1. 环境变量 LICENSE_CA_CERT 指定的路径
//   2. 应用根目录下的 certs/license.crt（打包后随 app 分发）
//   3. ~/.office-pet-stats/license.crt（手动放置）
let _caCert = null;
function getCA() {
  if (_caCert !== null) return _caCert;
  const candidates = [
    process.env.LICENSE_CA_CERT,
    path.join(__dirname, '..', 'certs', 'license.crt'),
    path.join(STATS_DIR, 'license.crt'),
  ].filter(Boolean);
  for (const p of candidates) {
    try {
      _caCert = fs.readFileSync(p);
      console.log(`🔒 已加载 License CA 证书: ${p}`);
      return _caCert;
    } catch (_) {}
  }
  _caCert = false; // 没找到，标记为已尝试
  return _caCert;
}

// 根据 URL 协议自动选择 http/https，HTTPS 时附带自签 CA
function getRequestModule(url) {
  if (url.protocol === 'https:') {
    const ca = getCA();
    const agent = ca
      ? new https.Agent({ ca })
      : new https.Agent({ rejectUnauthorized: false }); // 没证书时降级（仅开发用）
    return { mod: https, agent };
  }
  return { mod: http, agent: undefined };
}

// ── 机器指纹（稳定版：不依赖网络接口，换 WiFi 不变） ─────────────
function getMachineFingerprint() {
  const parts = [];
  // 1. Mac 序列号（全球唯一，永不变）
  try {
    const serial = execSync(
      "ioreg -l | grep IOPlatformSerialNumber | awk -F'\"' '{print $4}'",
      { encoding: 'utf-8', timeout: 5000 }
    ).trim();
    if (serial) parts.push(serial);
  } catch (_) {}
  // 2. 硬件 UUID（比 MAC 地址稳定，不受网络影响）
  try {
    const uuid = execSync(
      "ioreg -d2 -c IOPlatformExpertDevice | awk -F'\"' '/IOPlatformUUID/{print $4}'",
      { encoding: 'utf-8', timeout: 5000 }
    ).trim();
    if (uuid) parts.push(uuid);
  } catch (_) {}
  // 3. 用户名 + 主机名
  parts.push(os.userInfo().username || 'unknown');
  parts.push(os.hostname() || 'unknown');

  const hash = crypto.createHash('sha256').update(parts.join('|')).digest('hex');
  const short = hash.substring(0, 16).toUpperCase();
  return `${short.slice(0, 4)}-${short.slice(4, 8)}-${short.slice(8, 12)}-${short.slice(12, 16)}`;
}

// ── 安装日期（带 HMAC 签名防篡改） ────────────────────────────────
const META_SECRET = 'office-pet-meta-v1';

function signMeta(installDate, fingerprint) {
  return crypto.createHmac('sha256', META_SECRET)
    .update(`${installDate}|${fingerprint}`)
    .digest('hex').slice(0, 16);
}

function getInstallDate() {
  try {
    const meta = JSON.parse(fs.readFileSync(META_FILE, 'utf-8'));
    // 校验签名，防止用户篡改安装日期
    const expectedSig = signMeta(meta.installDate, meta.fingerprint);
    if (meta.sig !== expectedSig) {
      console.warn('⚠️ 安装元数据签名不匹配，视为首次安装');
      throw new Error('sig mismatch');
    }
    return new Date(meta.installDate);
  } catch (_) {
    const now = new Date();
    const fingerprint = getMachineFingerprint();
    if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
    const installDate = now.toISOString();
    fs.writeFileSync(META_FILE, JSON.stringify({
      installDate,
      fingerprint,
      sig: signMeta(installDate, fingerprint),
    }), 'utf-8');
    return now;
  }
}

function getTrialDaysLeft() {
  const elapsed = Math.floor((new Date() - getInstallDate()) / (1000 * 60 * 60 * 24));
  return Math.max(0, TRIAL_DAYS - elapsed);
}

// 精确到小时的试用剩余时间
function getTrialHoursLeft() {
  const elapsedMs = new Date() - getInstallDate();
  const totalMs = TRIAL_DAYS * 24 * 60 * 60 * 1000;
  return Math.max(0, (totalMs - elapsedMs) / (1000 * 60 * 60));
}

function isInTrialPeriod() {
  return getTrialDaysLeft() > 0;
}

// ── 试用到期提醒（24h / 12h） ───────────────────────────────────────
const REMINDER_FILE = path.join(STATS_DIR, '.trial-reminders.json');

function loadReminders() {
  try { return JSON.parse(fs.readFileSync(REMINDER_FILE, 'utf-8')); }
  catch (_) { return {}; }
}

function saveReminders(data) {
  if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
  fs.writeFileSync(REMINDER_FILE, JSON.stringify(data), 'utf-8');
}

/**
 * 检查是否需要发送试用到期提醒
 * 优先使用服务端剩余天数（防篡改），离线时降级到本地计算
 * @returns {string|null} 提醒消息，null 表示无需提醒
 */
async function checkTrialReminder() {
  const license = loadLicense();
  // 已有 License 的用户不需要提醒
  if (license && license.key) return null;

  // 优先从服务端获取精确剩余时间
  let hoursLeft = getTrialHoursLeft(); // 本地计算作为 fallback
  try {
    const fingerprint = getMachineFingerprint();
    const trialResult = await httpGet(`/api/trial?fingerprint=${fingerprint}`);
    if (typeof trialResult.trialDaysLeft === 'number') {
      hoursLeft = trialResult.trialDaysLeft * 24; // 服务端返回天数，转小时
    }
  } catch (_) {
    // 服务器不可达，用本地
  }

  // 不在试用期或剩余时间大于 24h，无需提醒
  if (hoursLeft <= 0 || hoursLeft > 24) return null;

  const reminders = loadReminders();
  const today = new Date().toISOString().slice(0, 10);

  if (hoursLeft <= 12 && !reminders.reminded12h) {
    reminders.reminded12h = today;
    saveReminders(reminders);
    return `⚠️ 试用期将在 ${Math.ceil(hoursLeft)} 小时后到期，请尽快申请 License！`;
  }

  if (hoursLeft <= 24 && !reminders.reminded24h) {
    reminders.reminded24h = today;
    saveReminders(reminders);
    return `⏰ 试用期还剩不到 24 小时，请联系管理员获取 License Key。`;
  }

  return null;
}

// ── 本地 License 读写 ──────────────────────────────────────────────
function loadLicense() {
  try { return JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf-8')); }
  catch (_) { return null; }
}

function saveLicense(data) {
  if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
  fs.writeFileSync(LICENSE_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// ── 离线缓存 ────────────────────────────────────────────────────────
function loadCache() {
  try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8')); }
  catch (_) { return null; }
}

function saveCache(data) {
  if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
  fs.writeFileSync(CACHE_FILE, JSON.stringify({ ...data, cachedAt: new Date().toISOString() }), 'utf-8');
}

function isCacheValid() {
  const cache = loadCache();
  if (!cache || !cache.valid || !cache.cachedAt) return false;
  const age = (new Date() - new Date(cache.cachedAt)) / (1000 * 60 * 60);
  return age < OFFLINE_GRACE_HOURS;
}

// ── HTTP/HTTPS 请求封装（自动识别协议，HTTPS 时附带自签 CA）────────
function httpPost(urlPath, body, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const url = new URL(LICENSE_SERVER + urlPath);
    const { mod, agent } = getRequestModule(url);
    const payload = JSON.stringify(body);
    const req = mod.request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'POST',
      timeout,
      agent,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON response')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(payload);
    req.end();
  });
}

function httpGet(urlPath, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const url = new URL(LICENSE_SERVER + urlPath);
    const { mod, agent } = getRequestModule(url);
    const req = mod.request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname + url.search,
      method: 'GET',
      timeout,
      agent,
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.end();
  });
}

// ── 在线校验 ────────────────────────────────────────────────────────
async function verifyOnline(key, fingerprint) {
  try {
    const result = await httpPost('/api/verify', { key, fingerprint });
    // 缓存校验结果
    saveCache(result);
    return result;
  } catch (err) {
    // 在线校验失败 → 降级到离线缓存
    console.warn(`⚠️ License 在线校验失败: ${err.message}，使用离线缓存`);
    if (isCacheValid()) {
      return { valid: true, reason: '离线模式（缓存有效）', offline: true };
    }
    return { valid: false, reason: `无法连接授权服务器，且离线缓存已过期（${OFFLINE_GRACE_HOURS}h）` };
  }
}

// ── 心跳续验 ────────────────────────────────────────────────────────
let heartbeatTimer = null;

function startHeartbeat(key, fingerprint) {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(async () => {
    try {
      const result = await httpPost('/api/heartbeat', {
        key,
        fingerprint,
        deviceInfo: { hostname: os.hostname(), platform: os.platform(), arch: os.arch() },
      });
      if (result.valid) {
        saveCache({ valid: true, reason: 'heartbeat ok' });
      } else {
        console.warn('⚠️ License 心跳校验失败，可能已被吊销');
      }
    } catch (_) {
      // 心跳失败不影响当前运行，但不更新缓存
    }
  }, HEARTBEAT_INTERVAL);
}

function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

// ── 综合授权检查（主入口） ──────────────────────────────────────────
async function checkAuthorization() {
  const fingerprint = getMachineFingerprint();
  const localTrialDays = getTrialDaysLeft(); // 本地计算，仅离线降级用
  const license = loadLicense();

  // 1. 有 License → 在线校验
  if (license && license.key) {
    const result = await verifyOnline(license.key, fingerprint);
    if (result.valid) {
      startHeartbeat(license.key, fingerprint);
      return { authorized: true, reason: `已授权：${result.reason}`, trialDaysLeft: 0, fingerprint };
    }
    // License 无效，继续检查试用期
  }

  // 2. 试用期检查 —— 服务端为权威来源，本地仅作离线降级
  const licenseExistsButInvalid = !!(license && license.key);
  let trialDays = localTrialDays; // 默认用本地
  let trialSource = 'local';

  try {
    const trialResult = await httpGet(`/api/trial?fingerprint=${fingerprint}`);
    if (trialResult.hasLicense && !licenseExistsButInvalid) {
      // 服务端确认有有效 License（本地文件可能丢失）
      return { authorized: true, reason: '服务端确认已授权', trialDaysLeft: 0, fingerprint };
    }
    // 服务端返回的试用天数为权威值——用户无法通过篡改本地文件来延长
    if (typeof trialResult.trialDaysLeft === 'number') {
      trialDays = trialResult.trialDaysLeft;
      trialSource = 'server';
    }
  } catch (_) {
    // 服务器不可达 → 降级使用本地计算（带 HMAC 签名保护）
    console.warn('⚠️ 授权服务器不可达，使用本地试用期计算（离线模式）');
  }

  if (trialDays > 0) {
    const suffix = trialSource === 'server' ? '' : '（离线模式）';
    return { authorized: true, reason: `试用期（剩余 ${trialDays} 天）${suffix}`, trialDaysLeft: trialDays, fingerprint };
  }

  // 3. 既无有效 License，试用期也过了
  return { authorized: false, reason: '试用期已结束，请激活 License', trialDaysLeft: 0, fingerprint };
}

// ── 激活 License ────────────────────────────────────────────────────
async function activateLicense(key) {
  const fingerprint = getMachineFingerprint();

  // 先在线验证这个 key 是否有效
  try {
    const result = await httpPost('/api/verify', { key, fingerprint });
    if (result.valid) {
      saveLicense({ key, fingerprint, activatedAt: new Date().toISOString() });
      saveCache(result);
      startHeartbeat(key, fingerprint);
      return { ok: true, ...result };
    }
    return { ok: false, ...result };
  } catch (err) {
    return { ok: false, valid: false, reason: `无法连接授权服务器: ${err.message}` };
  }
}

module.exports = {
  getMachineFingerprint,
  getInstallDate,
  getTrialDaysLeft,
  getTrialHoursLeft,
  isInTrialPeriod,
  loadLicense,
  checkAuthorization,
  checkTrialReminder,
  activateLicense,
  startHeartbeat,
  stopHeartbeat,
  LICENSE_FILE,
  STATS_DIR,
  LICENSE_SERVER,
};
