// ── Office Pet - App Logic ────────────────────────────────────────

const container = document.getElementById('pet-container');
const bubble = document.getElementById('bubble');
const bubbleTitle = bubble.querySelector('.bubble-title');
const bubbleMessage = bubble.querySelector('.bubble-message');
const statusDot = document.getElementById('status-dot');
const timerEl = document.getElementById('timer');
const timerCanvas = document.getElementById('timer-canvas');
const timerCtx = timerCanvas ? timerCanvas.getContext('2d') : null;
const dailyStatsEl = document.getElementById('daily-stats');
const dailyText = document.getElementById('daily-text');

let ws = null;
let reconnectTimer = null;
let bubbleTimer = null;
let waitingStartTime = null;
let timerInterval = null;
let isWaiting = false;
let currentDailyStats = { conversations: 0 };

// ── Pixel Font (3x5 bitmap digits + colon + T) ──────────────────────
const PIXEL_FONT = {
  '0': [0b111, 0b101, 0b101, 0b101, 0b111],
  '1': [0b010, 0b110, 0b010, 0b010, 0b111],
  '2': [0b111, 0b001, 0b111, 0b100, 0b111],
  '3': [0b111, 0b001, 0b111, 0b001, 0b111],
  '4': [0b101, 0b101, 0b111, 0b001, 0b001],
  '5': [0b111, 0b100, 0b111, 0b001, 0b111],
  '6': [0b111, 0b100, 0b111, 0b101, 0b111],
  '7': [0b111, 0b001, 0b010, 0b010, 0b010],
  '8': [0b111, 0b101, 0b111, 0b101, 0b111],
  '9': [0b111, 0b101, 0b111, 0b001, 0b111],
  ':': [0b0, 0b1, 0b0, 0b1, 0b0],
  'T': [0b111, 0b010, 0b010, 0b010, 0b010],
};

function drawPixelChar(ctx, char, x, y, color, scale) {
  const glyph = PIXEL_FONT[char];
  if (!glyph) return 0;
  const w = (char === ':') ? 1 : 3;
  ctx.fillStyle = color;
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < w; col++) {
      if (glyph[row] & (1 << (w - 1 - col))) {
        ctx.fillRect((x + col) * scale, (y + row) * scale, scale, scale);
      }
    }
  }
  return w;
}

function drawPixelTime(seconds) {
  if (!timerCtx) return;
  const W = timerCanvas.width;
  const H = timerCanvas.height;
  timerCtx.clearRect(0, 0, W, H);

  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  const timeStr = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');

  const scale = 3;
  const charWidths = [...timeStr].map(c => (c === ':' ? 1 : 3));
  const gaps = timeStr.length - 1;
  const totalW = charWidths.reduce((a, b) => a + b, 0) + gaps;
  let startX = Math.floor((W / scale - totalW) / 2);
  const startY = Math.floor((H / scale - 5) / 2);
  const colonVisible = seconds % 2 === 0;
  const color = '#ffc832';

  for (const ch of timeStr) {
    if (ch === ':' && !colonVisible) {
      startX += 1 + 1;
      continue;
    }
    const w = drawPixelChar(timerCtx, ch, startX, startY, color, scale);
    startX += w + 1;
  }
}

// ── Daily T display (idle mode) ─────────────────────────────────────
function drawDailyT() {
  if (!dailyText) return;
  const talks = currentDailyStats.conversations || 0;
  if (talks <= 0) {
    dailyText.textContent = '';
    return;
  }
  dailyText.textContent = `T${talks}`;
}

// ── Multi-session Panel ──────────────────────────────────────────────
const sessionsPanel = document.getElementById('sessions-panel');
let currentSessions = [];

const STATUS_ICONS = {
  running: '<span class="status-icon icon-running"><span></span><span></span><span></span></span>',
  waiting_approval: '<span class="status-icon icon-approval"><span></span></span>',
  done: '<span class="status-icon icon-done"><span></span><span></span></span>',
};

function formatTime(secs) {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}

function renderSessions(sessions) {
  if (!sessionsPanel) return;
  currentSessions = sessions;

  if (!sessions || sessions.length === 0) {
    sessionsPanel.classList.remove('show');
    sessionsPanel.classList.add('hidden');
    sessionsPanel.innerHTML = '';

    // Hide old timer too
    timerEl.classList.remove('show');
    timerEl.classList.add('hidden');
    dailyStatsEl.classList.remove('hidden');
    void dailyStatsEl.offsetWidth;
    dailyStatsEl.classList.add('show');

    if (window.setPetState) window.setPetState('idle');
    statusDot.className = 'status-dot idle';
    container.classList.remove('state-waiting');
    isWaiting = false;
    return;
  }

  // Hide old single timer + daily stats
  timerEl.classList.remove('show');
  timerEl.classList.add('hidden');
  dailyStatsEl.classList.remove('show');
  dailyStatsEl.classList.add('hidden');

  isWaiting = true;
  if (window.setPetState) window.setPetState('waiting');
  statusDot.className = 'status-dot waiting';
  container.classList.add('state-waiting');

  // Check if any session is waiting_approval
  const hasApproval = sessions.some(s => s.status === 'waiting_approval');
  if (hasApproval) {
    container.classList.add('state-approval');
  } else {
    container.classList.remove('state-approval');
  }

  // Build session rows
  sessionsPanel.innerHTML = sessions.map(s => {
    const icon = STATUS_ICONS[s.status] || STATUS_ICONS.running;
    const label = s.label || 'unknown';
    const desc = (s.description || '').slice(0, 10);
    const time = formatTime(s.elapsed);
    const statusClass = s.status || 'running';
    const approvalHint = s.status === 'waiting_approval' ? ' (等待授权)' : '';
    const titleText = desc ? `${label}${approvalHint} — ${desc}` : `${label}${approvalHint}`;
    return `<div class="session-row" title="${titleText}">
      <span class="session-label">${label}</span>
      ${desc ? `<span class="session-desc">${desc}</span>` : ''}
      <span class="session-time">${time}</span>
      <span class="session-status ${statusClass}">${icon}</span>
    </div>`;
  }).join('');

  sessionsPanel.classList.remove('hidden');
  sessionsPanel.classList.add('show');
}

// ── Timer control (legacy, now delegates to sessions) ────────────────
function startWaitingTimer() {
  // Legacy: handled by sessions-update now
  isWaiting = true;
}

function stopWaitingTimer() {
  isWaiting = false;
  container.classList.remove('state-waiting');
  container.classList.remove('state-approval');
}

// ── WebSocket Connection ─────────────────────────────────────────────
function connect() {
  const port = 13121;
  ws = new WebSocket(`ws://127.0.0.1:${port}/ws`);

  ws.onopen = () => {
    console.log('🐾 Connected to Office Pet server');
    if (!isWaiting) statusDot.className = 'status-dot idle';
    clearInterval(reconnectTimer);
  };

  ws.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      if (msg.type === 'notification') {
        handleNotification(msg);
      } else if (msg.type === 'sessions-update') {
        renderSessions(msg.sessions);
      } else if (msg.type === 'sound-toggle') {
        soundEnabled = msg.enabled;
      } else if (msg.type === 'start-waiting') {
        startWaitingTimer();
      } else if (msg.type === 'stop-waiting') {
        stopWaitingTimer();
      } else if (msg.type === 'feed') {
        playFeedAnimation();
      } else if (msg.type === 'pet-unlocked') {
        showUnlockToast(msg.pet);
      }
    } catch (err) {
      console.error('Parse error:', err);
    }
  };

  ws.onclose = () => {
    console.log('🔌 Disconnected, retrying...');
    reconnectTimer = setTimeout(connect, 3000);
  };

  ws.onerror = () => ws.close();
}

// ── Particle Burst Effect ────────────────────────────────────────────
const particleLayer = document.getElementById('particle-layer');
const PARTICLE_COLORS = ['#50dc64', '#ffc832', '#ff6b6b', '#64b5f6', '#fff', '#FFD700'];

function spawnParticles(count = 12) {
  if (!particleLayer) return;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.className = 'pixel-particle';
    const color = PARTICLE_COLORS[Math.floor(Math.random() * PARTICLE_COLORS.length)];
    p.style.background = color;
    const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.5;
    const dist = 20 + Math.random() * 30;
    p.style.setProperty('--px', Math.cos(angle) * dist + 'px');
    p.style.setProperty('--py', Math.sin(angle) * dist + 'px');
    p.style.left = '50%';
    p.style.top = '50%';
    p.style.width = (3 + Math.random() * 3) + 'px';
    p.style.height = p.style.width;
    p.style.animation = `particleBurst ${0.5 + Math.random() * 0.4}s cubic-bezier(0.25,0.46,0.45,0.94) forwards`;
    p.style.animationDelay = (Math.random() * 0.1) + 's';
    particleLayer.appendChild(p);
    setTimeout(() => p.remove(), 1200);
  }
}

// ── Glitter Idle Animation ──────────────────────────────────────────
const sparkleDots = document.querySelectorAll('.glitter-dot');
let sparkleInterval = null;

function startIdleSparkle() {
  stopIdleSparkle();
  sparkleInterval = setInterval(() => {
    const dot = sparkleDots[Math.floor(Math.random() * sparkleDots.length)];
    if (dot) {
      dot.classList.add('active');
      dot.style.animationDelay = (Math.random() * 0.5) + 's';
      setTimeout(() => dot.classList.remove('active'), 1800);
    }
  }, 2000);
}

function stopIdleSparkle() {
  clearInterval(sparkleInterval);
  sparkleDots.forEach(d => d.classList.remove('active'));
}

// ── Mood Emoji Float ────────────────────────────────────────────────
const moodEmoji = document.getElementById('mood-emoji');
const DONE_MOODS = ['🎉', '✨', '🚀', '💪', '🎊', '⭐'];
const WAIT_MOODS = ['🤔', '💭', '⏳', '🔄'];

function showMood(type) {
  if (!moodEmoji) return;
  const moods = type === 'done' ? DONE_MOODS : WAIT_MOODS;
  moodEmoji.textContent = moods[Math.floor(Math.random() * moods.length)];
  moodEmoji.classList.remove('show');
  void moodEmoji.offsetWidth;
  moodEmoji.classList.add('show');
  setTimeout(() => moodEmoji.classList.remove('show'), 2000);
}

// ── 8-bit Sound Effects (Web Audio API) ─────────────────────────────
let audioCtx = null;
let soundEnabled = true;

function getAudioCtx() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  // Chrome/Electron 自动播放策略：suspended 状态下需主动 resume
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

// 在任意用户交互（点击/移动）后尝试解锁音频上下文
function unlockAudioOnce() {
  const ctx = getAudioCtx();
  if (ctx.state === 'suspended') {
    ctx.resume().catch(() => {});
  }
  // 播放一个无声的超短音，激活 AudioContext
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.01);
  } catch (e) {}
}

// 首次任意用户交互时解锁
['click', 'mousedown', 'touchstart', 'keydown'].forEach(ev => {
  window.addEventListener(ev, unlockAudioOnce, { once: true, capture: true });
});

function playNote(ctx, freq, startTime, duration, vol = 0.15) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'square';
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(vol, startTime);
  gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(startTime);
  osc.stop(startTime + duration);
}

function playMarioSuccessSound() {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    // 确保激活
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    const t = ctx.currentTime + 0.02;
    // Super Mario stage clear melody (simplified 8-bit)
    const notes = [
      [523, 0.00, 0.12],  // C5
      [587, 0.12, 0.12],  // D5
      [659, 0.24, 0.12],  // E5
      [784, 0.36, 0.12],  // G5
      [880, 0.48, 0.12],  // A5
      [1047, 0.60, 0.18], // C6
      [880, 0.80, 0.12],  // A5
      [1047, 0.94, 0.30], // C6 (hold)
    ];
    notes.forEach(([freq, offset, dur]) => {
      playNote(ctx, freq, t + offset, dur, 0.22);  // 音量从 0.12 提到 0.22
    });
  } catch (e) {
    console.warn('Audio error:', e);
  }
}

// ── Touch Reaction (hearts/stars) ────────────────────────────────────
const touchLayer = document.getElementById('touch-layer');
const TOUCH_EMOJIS = ['💖', '✨', '⭐', '💕', '🌟', '💫'];

function spawnTouchHearts(count = 5) {
  if (!touchLayer) return;
  for (let i = 0; i < count; i++) {
    const h = document.createElement('div');
    h.className = 'touch-heart';
    h.textContent = TOUCH_EMOJIS[Math.floor(Math.random() * TOUCH_EMOJIS.length)];
    const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5);
    const dist = 15 + Math.random() * 20;
    h.style.setProperty('--hx', Math.cos(angle) * dist + 'px');
    h.style.setProperty('--hy', (Math.sin(angle) * dist - 10) + 'px');
    h.style.left = (30 + Math.random() * 20) + '%';
    h.style.top = (20 + Math.random() * 30) + '%';
    h.style.animationDelay = (Math.random() * 0.15) + 's';
    touchLayer.appendChild(h);
    setTimeout(() => h.remove(), 1200);
  }
}

window.onPetTouch = function() {
  // Squish animation
  container.classList.remove('pet-squish');
  void container.offsetWidth;
  container.classList.add('pet-squish');
  setTimeout(() => container.classList.remove('pet-squish'), 500);

  // Spawn hearts
  spawnTouchHearts(5);

  // Brief running state
  if (window.setPetState && !isWaiting) {
    window.setPetState('running');
    setTimeout(() => {
      if (!isWaiting) window.setPetState('idle');
    }, 800);
  }
};

// ── Feed System ─────────────────────────────────────────────────────
window.showFeedMenu = function(e) {
  e.preventDefault();
  if (window.electronAPI && window.electronAPI.showContextMenu) {
    window.electronAPI.showContextMenu({});
  }
};

// Listen for feed result from main process native menu
if (window.electronAPI && window.electronAPI.onFeedResult) {
  window.electronAPI.onFeedResult(() => {
    playFeedAnimation();
  });
}

// Click anywhere to close (no-op now, kept for safety)
document.addEventListener('click', () => {});

function playFeedAnimation() {
  const FOOD_EMOJIS = ['🍪', '🍩', '🍰', '🍫', '🍬', '🍭', '🧁', '🍡', '🥐', '🍎'];
  const food = FOOD_EMOJIS[Math.floor(Math.random() * FOOD_EMOJIS.length)];

  // Create food emoji element that flies to pet's mouth
  const foodEl = document.createElement('div');
  foodEl.textContent = food;
  foodEl.className = 'feed-food-fly';
  // Start from top-right area of the container
  const canvasEl = document.getElementById('pet-canvas');
  if (canvasEl) {
    const rect = canvasEl.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    // Start position: above and to the right of the pet
    foodEl.style.left = (rect.left - containerRect.left + rect.width * 0.8) + 'px';
    foodEl.style.top = (rect.top - containerRect.top - 8) + 'px';
    // End position: pet's mouth area (center-bottom of canvas)
    const endX = rect.left - containerRect.left + rect.width * 0.4;
    const endY = rect.top - containerRect.top + rect.height * 0.6;
    foodEl.style.setProperty('--end-x', endX + 'px');
    foodEl.style.setProperty('--end-y', endY + 'px');
  }
  container.appendChild(foodEl);

  // After food reaches mouth, play chomp sound + nom animation
  setTimeout(() => {
    // Pet eating wobble
    container.classList.remove('pet-eating');
    void container.offsetWidth;
    container.classList.add('pet-eating');
    setTimeout(() => container.classList.remove('pet-eating'), 600);

    // Chomp electronic sound
    playChompSound();

    // Happy reaction
    if (moodEmoji) {
      moodEmoji.textContent = '😋';
      moodEmoji.classList.remove('show');
      void moodEmoji.offsetWidth;
      moodEmoji.classList.add('show');
      setTimeout(() => moodEmoji.classList.remove('show'), 2000);
    }
  }, 500);

  // Remove food element after animation
  setTimeout(() => foodEl.remove(), 700);
}

function playChompSound() {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioCtx();
    const t = ctx.currentTime;
    // Electronic chomp: two quick descending blips
    playNote(ctx, 600, t, 0.06, 0.13);
    playNote(ctx, 450, t + 0.07, 0.06, 0.12);
    playNote(ctx, 800, t + 0.18, 0.05, 0.10);
    playNote(ctx, 500, t + 0.24, 0.05, 0.09);
    // Satisfied blip
    playNote(ctx, 900, t + 0.38, 0.08, 0.08);
    playNote(ctx, 1100, t + 0.46, 0.12, 0.07);
  } catch (e) {}
}

// ── Mood System ─────────────────────────────────────────────────────
const moodIndicator = document.getElementById('mood-indicator');
const MOOD_MAP = {
  happy:  '😊',
  normal: '😐',
  sleepy: '😴',
  sad:    '😢',
};

function updateMoodIndicator() {
  fetch('http://127.0.0.1:13121/mood')
    .then(r => r.json())
    .then(data => {
      if (moodIndicator && MOOD_MAP[data.mood]) {
        moodIndicator.textContent = MOOD_MAP[data.mood];
        moodIndicator.title = `心情: ${data.mood} | 连续 ${data.streak} 天`;
      }
      // Check unlock conditions based on mood data
      checkUnlocks(data);
    })
    .catch(() => {});
}

// ── Unlock Checking ─────────────────────────────────────────────────
function checkUnlocks(moodData) {
  if (!window.UNLOCK_CONDITIONS || !window.tryUnlockPet) return;

  // Build stats for condition checks
  // We need total conversations from all days
  fetch('http://127.0.0.1:13121/daily-stats')
    .then(r => r.json())
    .then(daily => {
      // Estimate total conversations: we'll count from unlocks file + today
      const stats = {
        todayConversations: daily.conversations || 0,
        totalConversations: daily.conversations || 0, // Will be enriched
        streak: moodData.streak || 0,
      };

      // Count total from history (check last 365 days)
      fetchTotalConversations().then(total => {
        stats.totalConversations = total;
        for (const [key, cond] of Object.entries(window.UNLOCK_CONDITIONS)) {
          if (cond.unlocked || window.isPetUnlocked(key)) continue;
          if (cond.check && cond.check(stats)) {
            window.tryUnlockPet(key);
            showUnlockToast(key);
          }
        }
      });
    })
    .catch(() => {});
}

let _cachedTotal = null;
let _cachedTotalTime = 0;

function fetchTotalConversations() {
  // Cache for 60s
  if (_cachedTotal !== null && Date.now() - _cachedTotalTime < 60000) {
    return Promise.resolve(_cachedTotal);
  }
  // We'll calculate by checking stats files via a new endpoint
  // For now, use a simple heuristic from streak + today
  return fetch('http://127.0.0.1:13121/daily-stats')
    .then(r => r.json())
    .then(data => {
      // Simple: today's count as baseline, real total needs server-side
      // We'll add a total endpoint
      return fetchTotalFromServer();
    })
    .catch(() => 0);
}

function fetchTotalFromServer() {
  return fetch('http://127.0.0.1:13121/total-conversations')
    .then(r => r.json())
    .then(data => {
      _cachedTotal = data.total || 0;
      _cachedTotalTime = Date.now();
      return _cachedTotal;
    })
    .catch(() => 0);
}

// ── Unlock Toast ────────────────────────────────────────────────────
const unlockToast = document.getElementById('unlock-toast');
const unlockText = unlockToast ? unlockToast.querySelector('.unlock-text') : null;

function showUnlockToast(petKey) {
  if (!unlockToast || !unlockText || !window.pets || !window.pets[petKey]) return;
  const pet = window.pets[petKey];
  unlockText.textContent = `解锁了 ${pet.name} (${pet.rarity})！`;
  unlockToast.classList.remove('hidden');
  void unlockToast.offsetWidth;
  unlockToast.classList.add('show');

  // Celebration particles
  spawnParticles(20);

  // Reload unlocked pets
  if (window.loadUnlockedPets) window.loadUnlockedPets();

  setTimeout(() => {
    unlockToast.classList.remove('show');
    setTimeout(() => unlockToast.classList.add('hidden'), 400);
  }, 4000);
}

// ── Notification Handler ─────────────────────────────────────────────
function handleNotification(msg) {
  const { title, message, notifyType, stillWaiting, sessions } = msg;

  if (!stillWaiting) stopWaitingTimer();
  stopIdleSparkle();
  hideDailyStats();

  // 通知展开时，隐藏会话面板，只显示气泡（避免内容挤压）
  sessionsPanel.classList.remove('show');
  sessionsPanel.classList.add('hidden');

  // Play sound effect
  if (notifyType === 'done') playMarioSuccessSound();

  statusDot.className = `status-dot ${notifyType || 'done'}`;

  const stateMap = { 'done': 'running', 'waiting': 'waiting', 'error': 'waiting' };
  if (window.setPetState) window.setPetState(stateMap[notifyType] || 'running');

  container.className = '';
  container.classList.add('shape-expanded');
  container.classList.add(`notify-${notifyType || 'done'}`);

  container.classList.add('pet-bounce');
  setTimeout(() => container.classList.remove('pet-bounce'), 600);

  spawnParticles(16);
  showMood(notifyType || 'done');
  showBubble(title, message);

  if (window.electronAPI && window.electronAPI.requestExpand) {
    window.electronAPI.requestExpand(message);
  }

  clearTimeout(bubbleTimer);
  bubbleTimer = setTimeout(() => {
    hideBubble();
    container.classList.remove(`notify-${notifyType || 'done'}`);

    if (stillWaiting && sessions && sessions.length > 0) {
      renderSessions(sessions);
      if (window.electronAPI && window.electronAPI.requestExpand) {
        window.electronAPI.requestExpand('__timer__');
      }
    } else {
      renderSessions([]);
      if (window.setPetState) window.setPetState('idle');
      statusDot.className = 'status-dot idle';
      container.className = '';
      // 不加 shape-expanded，让背景恢复透明（hover 时才显深色）
      startIdleSparkle();
      fetch('http://127.0.0.1:13121/daily-stats')
        .then(r => r.json())
        .then(data => { currentDailyStats = data; showDailyStats(); })
        .catch(() => showDailyStats());
      if (window.electronAPI && window.electronAPI.requestShrink) {
        window.electronAPI.requestShrink();
      }
      setTimeout(updateMoodIndicator, 500);
    }
  }, 30000);
}

// ── Bubble Show/Hide ─────────────────────────────────────────────────
function showBubble(title, message) {
  bubbleTitle.textContent = title || 'Office Pet';
  bubbleMessage.textContent = message || '';
  bubble.classList.remove('hidden');
  void bubble.offsetWidth;
  bubble.classList.add('show');
}

function hideBubble() {
  bubble.classList.remove('show');
  setTimeout(() => bubble.classList.add('hidden'), 400);
}

// ── Daily Stats Display (idle mode, T only) ─────────────────────────
function showDailyStats() {
  if (isWaiting) return;
  if ((currentDailyStats.conversations || 0) <= 0) return;
  drawDailyT();
  dailyStatsEl.classList.remove('hidden');
  void dailyStatsEl.offsetWidth;
  dailyStatsEl.classList.add('show');
}

function hideDailyStats() {
  dailyStatsEl.classList.remove('show');
  dailyStatsEl.classList.add('hidden');
}

function loadInitialDailyStats() {
  fetch('http://127.0.0.1:13121/daily-stats')
    .then(r => r.json())
    .then(data => {
      currentDailyStats = data;
      if (!isWaiting) showDailyStats();
    })
    .catch(() => {});
}

// ── Init ─────────────────────────────────────────────────────────────
connect();
startIdleSparkle();

// ── Close Button ─────────────────────────────────────────────────────
const closeBtn = document.getElementById('close-btn');
if (closeBtn) {
  closeBtn.addEventListener('mousedown', (e) => {
    e.stopPropagation(); // 阻止触发拖拽
  });
  closeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (window.electronAPI && window.electronAPI.closeApp) {
      window.electronAPI.closeApp();
    }
  });
}
setTimeout(loadInitialDailyStats, 500);
setTimeout(updateMoodIndicator, 1000);
// Periodically refresh mood
setInterval(updateMoodIndicator, 60000);

// ── JS Manual Drag ───────────────────────────────────────────────────
let isDragging = false;

document.addEventListener('mousedown', (e) => {
  if (e.button !== 0 || e.ctrlKey) return; // exclude right-click & ctrl+click (trackpad)
  // 不在关闭按钮上触发拖拽
  if (e.target.closest('.close-btn')) return;
  isDragging = true;
  if (window.electronAPI && window.electronAPI.startDrag) window.electronAPI.startDrag();
});

document.addEventListener('mouseup', () => {
  if (!isDragging) return;
  isDragging = false;
  if (window.electronAPI && window.electronAPI.stopDrag) window.electronAPI.stopDrag();
});

document.addEventListener('contextmenu', (e) => {
  // Stop any accidental drag when context menu opens
  if (isDragging) {
    isDragging = false;
    if (window.electronAPI && window.electronAPI.stopDrag) window.electronAPI.stopDrag();
  }
});

// ── Shape change from main process ──────────────────────────────────
const wrapper = document.getElementById('pet-wrapper');
if (window.electronAPI && window.electronAPI.onShapeChange) {
  window.electronAPI.onShapeChange((shape) => {
    if (shape === 'expanded') {
      // 只在真正展开（通知/会话面板）时加深色背景
      container.classList.add('shape-expanded');
      wrapper.classList.add('layout-expanded');
    } else if (shape === 'idle-pill') {
      // idle 态：保持透明，仅布局展开
      container.classList.remove('shape-expanded');
      wrapper.classList.add('layout-expanded');
    } else {
      container.classList.remove('shape-expanded');
      wrapper.classList.remove('layout-expanded');
    }
  });
}
