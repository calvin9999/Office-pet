// ══ 5 只宠物：REX, AMBER, MOCHI, LUNA, MIDNIGHT ══
(function() {
const { drawEye, drawSlitEye, drawBlush, drawNose, shadowOn, shadowOff, canvas, ctx, clearCanvas } = window.__furryHelpers;
const furryPets = window.__furryPets;

// 1. REX - 赛博朋克坐狼（坐姿 + 霓虹耳 + 圆润身）
furryPets.rex = {
  name: "Rex · 电狼", rarity: "UR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const breath = Math.sin(t*2)*0.6;
    const MAIN='#6B7FAC', DARK='#3D4F76', LIGHT='#B8CCE8', WHITE='#F0F6FC';
    const NEON='#00F0FF', NEON2='#FF3D7F';

    // —— 坐姿尾巴（卷在身侧） ——
    const wag = Math.sin(t*3)*4;
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(cx+14, H-10);
    ctx.bezierCurveTo(cx+24+wag, H-14, cx+26+wag, H-26, cx+18+wag, H-30);
    ctx.bezierCurveTo(cx+12+wag, H-32, cx+10, H-24, cx+12, H-14);
    ctx.closePath(); ctx.fill();
    // 尾尖白毛
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx+18+wag, H-30, 5, 4, 0, 0, Math.PI*2); ctx.fill();

    // —— 霓虹光晕（尾尖） ——
    ctx.save();
    ctx.shadowColor = NEON; ctx.shadowBlur = 6;
    ctx.fillStyle = NEON;
    ctx.globalAlpha = 0.6;
    ctx.beginPath(); ctx.arc(cx+18+wag, H-30, 2, 0, Math.PI*2); ctx.fill();
    ctx.restore();

    // —— 后腿（坐姿，叠在身下） ——
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.ellipse(cx-14, H-10, 7, 5, 0.2, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+14, H-10, 7, 5, -0.2, 0, Math.PI*2); ctx.fill();
    // 脚趾
    ctx.fillStyle = darkenColorLocal(DARK);
    for (const [px, py, d] of [[-14, H-8, -1], [14, H-8, 1]]) {
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath(); ctx.arc(cx+px+i*2, py, 0.9, 0, Math.PI*2); ctx.fill();
      }
    }

    // —— 圆润身体（坐着的梨形） ——
    shadowOn(DARK);
    const bg = ctx.createRadialGradient(cx-4, H/2+16+breath, 4, cx, H/2+22+breath, 22);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.55, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22+breath, 17, 18, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();

    // 胸部白毛（心形）
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(cx, H/2+14+breath);
    ctx.bezierCurveTo(cx-9, H/2+10+breath, cx-10, H/2+24+breath, cx, H-6);
    ctx.bezierCurveTo(cx+10, H/2+24+breath, cx+9, H/2+10+breath, cx, H/2+14+breath);
    ctx.fill();

    // 前爪（贴在身前）
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.ellipse(cx-8, H-8, 4.5, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+8, H-8, 4.5, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx-8, H-7, 3, 2, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+8, H-7, 3, 2, 0, 0, Math.PI*2); ctx.fill();

    // ═══ 头部 ═══
    const hx = cx, hy = H/2-2+breath*0.3;

    // 大头本体（圆润狼头）
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-5, hy-6, 2, hx, hy, 19);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.65, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath();
    // 头顶圆弧
    ctx.moveTo(hx-17, hy-2);
    ctx.quadraticCurveTo(hx-18, hy-14, hx-8, hy-17);
    ctx.lineTo(hx+8, hy-17);
    ctx.quadraticCurveTo(hx+18, hy-14, hx+17, hy-2);
    // 脸颊鼓起
    ctx.quadraticCurveTo(hx+17, hy+10, hx+10, hy+14);
    // 圆口鼻
    ctx.quadraticCurveTo(hx+6, hy+18, hx, hy+18);
    ctx.quadraticCurveTo(hx-6, hy+18, hx-10, hy+14);
    ctx.quadraticCurveTo(hx-17, hy+10, hx-17, hy-2);
    ctx.closePath(); ctx.fill();
    shadowOff();

    // 白色面部（从眉心到下巴）
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(hx, hy-12);
    ctx.bezierCurveTo(hx-10, hy-8, hx-12, hy+4, hx-8, hy+12);
    ctx.quadraticCurveTo(hx-4, hy+17, hx, hy+17);
    ctx.quadraticCurveTo(hx+4, hy+17, hx+8, hy+12);
    ctx.bezierCurveTo(hx+12, hy+4, hx+10, hy-8, hx, hy-12);
    ctx.fill();

    // —— 尖耳朵（带霓虹描边） ——
    // 左耳外
    ctx.fillStyle = DARK;
    ctx.beginPath();
    ctx.moveTo(hx-16, hy-10);
    ctx.quadraticCurveTo(hx-20, hy-24, hx-12, hy-26);
    ctx.quadraticCurveTo(hx-8, hy-20, hx-9, hy-14);
    ctx.closePath(); ctx.fill();
    // 耳内粉
    ctx.fillStyle = '#FFB4C0';
    ctx.beginPath();
    ctx.moveTo(hx-15, hy-12);
    ctx.quadraticCurveTo(hx-17, hy-22, hx-12, hy-23);
    ctx.quadraticCurveTo(hx-10, hy-18, hx-11, hy-14);
    ctx.closePath(); ctx.fill();
    // 霓虹边
    ctx.save();
    ctx.shadowColor = NEON; ctx.shadowBlur = 4;
    ctx.strokeStyle = NEON; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(hx-16, hy-10);
    ctx.quadraticCurveTo(hx-20, hy-24, hx-12, hy-26);
    ctx.stroke();
    ctx.restore();

    // 右耳
    ctx.fillStyle = DARK;
    ctx.beginPath();
    ctx.moveTo(hx+16, hy-10);
    ctx.quadraticCurveTo(hx+20, hy-24, hx+12, hy-26);
    ctx.quadraticCurveTo(hx+8, hy-20, hx+9, hy-14);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFB4C0';
    ctx.beginPath();
    ctx.moveTo(hx+15, hy-12);
    ctx.quadraticCurveTo(hx+17, hy-22, hx+12, hy-23);
    ctx.quadraticCurveTo(hx+10, hy-18, hx+11, hy-14);
    ctx.closePath(); ctx.fill();
    ctx.save();
    ctx.shadowColor = NEON; ctx.shadowBlur = 4;
    ctx.strokeStyle = NEON; ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(hx+16, hy-10);
    ctx.quadraticCurveTo(hx+20, hy-24, hx+12, hy-26);
    ctx.stroke();
    ctx.restore();

    // —— 额头霓虹光标（赛博标记） ——
    const markPulse = Math.sin(t*3)*0.3+0.7;
    ctx.save();
    ctx.shadowColor = NEON; ctx.shadowBlur = 6*markPulse;
    ctx.fillStyle = NEON;
    ctx.globalAlpha = markPulse;
    ctx.beginPath();
    // 菱形标记
    ctx.moveTo(hx, hy-10);
    ctx.lineTo(hx+2, hy-8);
    ctx.lineTo(hx, hy-6);
    ctx.lineTo(hx-2, hy-8);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // —— 大圆眼（青色） ——
    const blink = (t%3.5<0.12)?0.15:1;
    const lx = state==='running'?Math.sin(t*8)*0.6:Math.sin(t*1.5)*0.3;
    ctx.save();
    ctx.shadowColor = NEON; ctx.shadowBlur = 3;
    drawEye(hx-7, hy-3, 4.5, '#00D4C0', {x:lx, y:0}, blink);
    drawEye(hx+7, hy-3, 4.5, '#00D4C0', {x:lx, y:0}, blink);
    ctx.restore();

    // —— 粉色小鼻 ——
    drawNose(hx, hy+8, 2.8, '#FF5577');

    // —— 嘴（友好） ——
    if (state === 'running') {
      // 开心吐舌
      ctx.fillStyle = '#2A1010';
      ctx.beginPath(); ctx.ellipse(hx, hy+13, 4, 3, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#FF6B8A';
      ctx.beginPath(); ctx.ellipse(hx, hy+14.5, 2, 2, 0, 0, Math.PI*2); ctx.fill();
    } else {
      ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 1.2; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(hx, hy+11); ctx.lineTo(hx, hy+13);
      ctx.moveTo(hx, hy+13);
      ctx.quadraticCurveTo(hx-3, hy+15, hx-5, hy+14);
      ctx.moveTo(hx, hy+13);
      ctx.quadraticCurveTo(hx+3, hy+15, hx+5, hy+14);
      ctx.stroke();
    }

    // 腮红
    drawBlush(hx-11, hx+11, hy+5, 0.35, 3.5);

    // —— 颈部霓虹项圈 ——
    ctx.save();
    ctx.shadowColor = NEON2; ctx.shadowBlur = 4;
    ctx.strokeStyle = NEON2; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(hx-13, hy+17);
    ctx.quadraticCurveTo(hx, hy+20, hx+13, hy+17);
    ctx.stroke();
    ctx.restore();
    // 项圈吊坠
    ctx.fillStyle = NEON2;
    ctx.save();
    ctx.shadowColor = NEON2; ctx.shadowBlur = 3;
    ctx.beginPath(); ctx.arc(hx, hy+20, 1.5, 0, Math.PI*2); ctx.fill();
    ctx.restore();
  }
};

// 内部辅助：颜色略暗
function darkenColorLocal(rgb) {
  // 如果是 rgb() 字符串，解析后减亮度
  const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/.exec(rgb);
  if (m) {
    const r = Math.max(0, parseInt(m[1])-30), g = Math.max(0, parseInt(m[2])-30), b = Math.max(0, parseInt(m[3])-30);
    return `rgb(${r},${g},${b})`;
  }
  return rgb;
}

// 2. AMBER - 赤狐（蓬松大尾 + 尖嘴 + 泪痕）
furryPets.amber = {
  name: "Amber · 狐娘", rarity: "SSR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const bounce = state==='running'?Math.abs(Math.sin(t*9))*2:Math.sin(t*2)*0.8;
    const MAIN='#E07830', DARK='#A04518', LIGHT='#FFAA60', WHITE='#FFF5EB', BLACK='#2a1a14';
    // 蓬松尾
    const tail = Math.sin(t*2)*4;
    const tg = ctx.createRadialGradient(cx+18+tail, H/2-8, 3, cx+18+tail, H/2-8, 18);
    tg.addColorStop(0, LIGHT); tg.addColorStop(0.6, MAIN); tg.addColorStop(1, DARK);
    ctx.fillStyle = tg;
    ctx.beginPath(); ctx.ellipse(cx+18+tail, H/2-6, 12, 16, -0.3+tail*0.02, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx+24+tail*1.2, H/2-16, 6, 7, -0.3, 0, Math.PI*2); ctx.fill();
    // 黑腿
    ctx.fillStyle = BLACK;
    ctx.fillRect(cx-10, H-16-bounce*0.5, 5, 12);
    ctx.fillRect(cx+5, H-16-bounce*0.5, 5, 12);
    // 流线身
    shadowOn(DARK);
    const bg = ctx.createLinearGradient(cx, H/2+10, cx, H-14);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.4, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22-bounce, 14, 16, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx-1, H/2+25-bounce, 6, 10, 0, 0, Math.PI*2); ctx.fill();
    // 倒三角脸
    const hx = cx, hy = H/2-2-bounce;
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-3, hy-4, 2, hx, hy, 18);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath();
    ctx.moveTo(hx-16, hy-4);
    ctx.quadraticCurveTo(hx-18, hy-13, hx-10, hy-15);
    ctx.lineTo(hx+10, hy-15);
    ctx.quadraticCurveTo(hx+18, hy-13, hx+16, hy-4);
    ctx.quadraticCurveTo(hx+10, hy+12, hx+2, hy+16);
    ctx.lineTo(hx-2, hy+16);
    ctx.quadraticCurveTo(hx-10, hy+12, hx-16, hy-4);
    ctx.closePath(); ctx.fill();
    shadowOff();
    // 白鼻部
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(hx-8, hy+2);
    ctx.quadraticCurveTo(hx-7, hy+13, hx, hy+16);
    ctx.quadraticCurveTo(hx+7, hy+13, hx+8, hy+2);
    ctx.quadraticCurveTo(hx, hy+7, hx-8, hy+2);
    ctx.fill();
    // 修长耳
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.moveTo(hx-14,hy-9); ctx.lineTo(hx-20,hy-26); ctx.lineTo(hx-8,hy-14); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+14,hy-9); ctx.lineTo(hx+20,hy-26); ctx.lineTo(hx+8,hy-14); ctx.closePath(); ctx.fill();
    ctx.fillStyle = BLACK;
    ctx.beginPath(); ctx.moveTo(hx-16,hy-15); ctx.lineTo(hx-20,hy-26); ctx.lineTo(hx-13,hy-17); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+16,hy-15); ctx.lineTo(hx+20,hy-26); ctx.lineTo(hx+13,hy-17); ctx.closePath(); ctx.fill();
    // 泪痕
    ctx.strokeStyle = BLACK; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(hx-7,hy-2); ctx.quadraticCurveTo(hx-8,hy+2,hx-5,hy+6); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx+7,hy-2); ctx.quadraticCurveTo(hx+8,hy+2,hx+5,hy+6); ctx.stroke();
    const blink = (t%3.2<0.1)?0.15:1;
    const lx = Math.sin(t*1.5)*0.6;
    drawEye(hx-6, hy-4, 4, '#4A90D9', {x:lx,y:0}, blink);
    drawEye(hx+6, hy-4, 4, '#4A90D9', {x:lx,y:0}, blink);
    drawNose(hx, hy+9, 2, BLACK);
    ctx.strokeStyle = BLACK; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(hx,hy+11); ctx.lineTo(hx,hy+13);
    ctx.moveTo(hx,hy+13); ctx.quadraticCurveTo(hx-2,hy+15,hx-4,hy+13.5);
    ctx.moveTo(hx,hy+13); ctx.quadraticCurveTo(hx+2,hy+15,hx+4,hy+13.5); ctx.stroke();
    drawBlush(hx-10, hx+10, hy+5, 0.35, 3);
  }
};

// 3. MOCHI - 坐姿胖橘猫（梨形身 + 折耳 + M字虎斑）
furryPets.mochi = {
  name: "Mochi · 橘座", rarity: "SSR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const purr = Math.sin(t*6)*0.4;
    const MAIN='#F5A623', DARK='#C87A10', LIGHT='#FFD566', WHITE='#FFF8F0', STRIPE='#B86810';
    // 卷尾前身
    const tip = Math.sin(t*3)*2;
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(cx+18, H-12);
    ctx.quadraticCurveTo(cx+26, H-18, cx+22, H-26);
    ctx.quadraticCurveTo(cx+16, H-30+tip, cx+10, H-24);
    ctx.lineTo(cx+14, H-14); ctx.closePath(); ctx.fill();
    ctx.fillStyle = STRIPE;
    for (let i=0;i<3;i++) { ctx.beginPath(); ctx.ellipse(cx+18+i, H-18-i*3, 3, 1, -0.5, 0, Math.PI*2); ctx.fill(); }
    // 梨形胖身
    shadowOn(DARK);
    const bg = ctx.createRadialGradient(cx-4, H/2+8, 3, cx, H/2+16, 22);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.7, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+20+purr, 20, 18, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 虎斑
    ctx.fillStyle = STRIPE; ctx.globalAlpha = 0.45;
    for (let i=0;i<4;i++) {
      ctx.beginPath(); ctx.ellipse(cx-12+i*2, H/2+12+i*2, 2.5, 1, 0.3, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(cx+10-i*2, H/2+12+i*2, 2.5, 1, -0.3, 0, Math.PI*2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // 白肚
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx, H/2+26+purr, 8, 10, 0, 0, Math.PI*2); ctx.fill();
    // 前爪
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.ellipse(cx-10, H-10, 5, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+10, H-10, 5, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#FFB4C0';
    ctx.beginPath(); ctx.ellipse(cx-10, H-9, 2.5, 1.8, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+10, H-9, 2.5, 1.8, 0, 0, Math.PI*2); ctx.fill();
    // 大圆头
    const hx = cx, hy = H/2-2+purr*0.3;
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-4, hy-5, 2, hx, hy, 18);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.arc(hx, hy, 17, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 圆脸颊
    ctx.fillStyle = LIGHT;
    ctx.beginPath(); ctx.arc(hx-12, hy+6, 5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+12, hy+6, 5, 0, Math.PI*2); ctx.fill();
    // 白口鼻
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx, hy+6, 9, 6, 0, 0, Math.PI*2); ctx.fill();
    // 折耳
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(hx-14,hy-8); ctx.quadraticCurveTo(hx-16,hy-18,hx-8,hy-16); ctx.quadraticCurveTo(hx-6,hy-10,hx-10,hy-8); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(hx+14,hy-8); ctx.quadraticCurveTo(hx+16,hy-18,hx+8,hy-16); ctx.quadraticCurveTo(hx+6,hy-10,hx+10,hy-8); ctx.fill();
    ctx.fillStyle = '#FFB4C0';
    ctx.beginPath(); ctx.ellipse(hx-11,hy-12,2,3,-0.4,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(hx+11,hy-12,2,3,0.4,0,Math.PI*2); ctx.fill();
    // M 额纹
    ctx.strokeStyle = STRIPE; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(hx-5,hy-10); ctx.lineTo(hx-3,hy-5); ctx.lineTo(hx,hy-10); ctx.lineTo(hx+3,hy-5); ctx.lineTo(hx+5,hy-10);
    ctx.stroke();
    // 眯眼/竖瞳
    if (state === 'waiting') {
      ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.arc(hx-7,hy-1,3.5,Math.PI*0.15,Math.PI*0.85,true); ctx.stroke();
      ctx.beginPath(); ctx.arc(hx+7,hy-1,3.5,Math.PI*0.15,Math.PI*0.85,true); ctx.stroke();
    } else {
      const lx = Math.sin(t*2)*0.5;
      drawSlitEye(hx-7, hy-2, 4.2, '#3CB371', {x:lx});
      drawSlitEye(hx+7, hy-2, 4.2, '#3CB371', {x:lx});
    }
    drawNose(hx, hy+3, 2.2, '#FF69B4');
    ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(hx,hy+5); ctx.lineTo(hx,hy+8);
    ctx.moveTo(hx,hy+8); ctx.quadraticCurveTo(hx-2,hy+11,hx-4,hy+9);
    ctx.moveTo(hx,hy+8); ctx.quadraticCurveTo(hx+2,hy+11,hx+4,hy+9); ctx.stroke();
    // 胡须
    ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 0.8;
    for (let i=-1;i<=1;i++) {
      ctx.beginPath(); ctx.moveTo(hx-8,hy+4+i*2); ctx.lineTo(hx-18,hy+3+i*3); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(hx+8,hy+4+i*2); ctx.lineTo(hx+18,hy+3+i*3); ctx.stroke();
    }
    drawBlush(hx-12, hx+12, hy+4, 0.45, 3.5);
  }
};

// 4. LUNA - 长耳兔（超长竖耳 + 大门牙）
furryPets.luna = {
  name: "Luna · 月兔", rarity: "SR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const hop = state==='running'?Math.abs(Math.sin(t*10))*4:0;
    const MAIN='#F0E4D7', DARK='#BCA690', LIGHT='#FFFAF0', INNER='#FFB6C1';
    // 超长竖耳
    const sway = state==='running'?Math.sin(t*10)*0.15:Math.sin(t*1.5)*0.04;
    for (const [ox, side] of [[-8,-1],[8,1]]) {
      ctx.save();
      ctx.translate(cx+ox, H/2-4-hop);
      ctx.rotate(side*0.15+side*sway);
      ctx.fillStyle = MAIN;
      ctx.beginPath(); ctx.ellipse(0,-16,5,20,0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle = INNER;
      ctx.beginPath(); ctx.ellipse(0,-16,2.5,16,0,0,Math.PI*2); ctx.fill();
      ctx.restore();
    }
    // 后腿
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.ellipse(cx-12,H-10-hop*0.5,6,5,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+12,H-10-hop*0.5,6,5,0,0,Math.PI*2); ctx.fill();
    // 圆身
    shadowOn(DARK);
    const bg = ctx.createRadialGradient(cx-3, H/2+18, 2, cx, H/2+22, 18);
    bg.addColorStop(0, LIGHT); bg.addColorStop(1, MAIN);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22-hop, 15, 14, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 圆球尾
    ctx.fillStyle = LIGHT;
    ctx.beginPath(); ctx.arc(cx+15, H/2+18-hop, 4.5, 0, Math.PI*2); ctx.fill();
    // 小圆头
    const hx = cx, hy = H/2-hop;
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-3, hy-4, 2, hx, hy, 15);
    hg.addColorStop(0, LIGHT); hg.addColorStop(1, MAIN);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.arc(hx, hy, 14, 0, Math.PI*2); ctx.fill();
    shadowOff();
    ctx.fillStyle = LIGHT;
    ctx.beginPath(); ctx.arc(hx-10,hy+4,4,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+10,hy+4,4,0,Math.PI*2); ctx.fill();
    const blink = (t%3<0.1)?0.1:1;
    drawEye(hx-5, hy-2, 3.8, '#E85A9A', {x:0,y:0}, blink);
    drawEye(hx+5, hy-2, 3.8, '#E85A9A', {x:0,y:0}, blink);
    // Y鼻
    ctx.fillStyle = '#FF89AA';
    ctx.beginPath();
    ctx.moveTo(hx-1.5,hy+4); ctx.lineTo(hx,hy+6); ctx.lineTo(hx+1.5,hy+4); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#FF89AA'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(hx,hy+6); ctx.lineTo(hx,hy+8); ctx.stroke();
    // 大门牙
    ctx.fillStyle = '#FFFFFF'; ctx.strokeStyle = '#DDDDDD'; ctx.lineWidth = 0.6;
    ctx.fillRect(hx-2.8,hy+8,2.4,4); ctx.strokeRect(hx-2.8,hy+8,2.4,4);
    ctx.fillRect(hx+0.4,hy+8,2.4,4); ctx.strokeRect(hx+0.4,hy+8,2.4,4);
    drawBlush(hx-10, hx+10, hy+3, 0.45, 3);
  }
};

// 5. MIDNIGHT - 匍匐黑豹（低伏 + 金瞳 + 玫瑰斑）
furryPets.midnight = {
  name: "Midnight · 夜豹", rarity: "UR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const MAIN='#2D2D3A', DARK='#14141C', LIGHT='#4A4A5C', ACCENT='#0A0A12';
    // 甩尾
    const tp = t*3;
    ctx.strokeStyle = MAIN; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cx+18, H/2+10);
    ctx.bezierCurveTo(cx+28, H/2+5+Math.sin(tp)*4, cx+26, H/2-5+Math.sin(tp+0.5)*4, cx+20, H/2-18);
    ctx.stroke();
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.arc(cx+20, H/2-18, 3, 0, Math.PI*2); ctx.fill();
    // 低伏长身
    shadowOn(ACCENT);
    const bg = ctx.createLinearGradient(cx, H/2+15, cx, H-10);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.5, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+24, 22, 12, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 前爪
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.ellipse(cx-14, H-10, 7, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+14, H-10, 7, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = ACCENT;
    for (const s of [-14, 14]) for (let i=-1;i<=1;i++) {
      ctx.beginPath(); ctx.arc(cx+s+i*2, H-7, 0.8, 0, Math.PI*2); ctx.fill();
    }
    // 玫瑰斑
    ctx.strokeStyle = ACCENT; ctx.lineWidth = 0.8; ctx.globalAlpha = 0.6;
    for (const [rx,ry] of [[-10,22],[0,20],[10,22],[-6,28],[6,28]]) {
      ctx.beginPath(); ctx.arc(cx+rx, H/2+ry, 2.5, 0, Math.PI*2); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    // 头
    const hx = cx, hy = H/2+8;
    shadowOn(ACCENT);
    const hg = ctx.createRadialGradient(hx-3, hy-4, 1, hx, hy, 15);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.ellipse(hx, hy, 15, 13, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 贴头耳
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.moveTo(hx-10,hy-10); ctx.lineTo(hx-13,hy-18); ctx.lineTo(hx-6,hy-13); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+10,hy-10); ctx.lineTo(hx+13,hy-18); ctx.lineTo(hx+6,hy-13); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#6B3B2B';
    ctx.beginPath(); ctx.moveTo(hx-10,hy-12); ctx.lineTo(hx-12,hy-17); ctx.lineTo(hx-8,hy-13); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+10,hy-12); ctx.lineTo(hx+12,hy-17); ctx.lineTo(hx+8,hy-13); ctx.closePath(); ctx.fill();
    // 发光金瞳
    const glow = Math.sin(t*2)*0.3+0.7;
    ctx.save();
    ctx.shadowColor = `rgba(255,215,0,${glow})`; ctx.shadowBlur = 6;
    const lx = Math.sin(t*1.5)*0.5;
    drawSlitEye(hx-6, hy-2, 4, '#FFD700', {x:lx});
    drawSlitEye(hx+6, hy-2, 4, '#FFD700', {x:lx});
    ctx.restore();
    drawNose(hx, hy+5, 2, '#1a1a1a');
    ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(hx,hy+7); ctx.lineTo(hx,hy+9);
    ctx.moveTo(hx,hy+9); ctx.quadraticCurveTo(hx-3,hy+11,hx-5,hy+10);
    ctx.moveTo(hx,hy+9); ctx.quadraticCurveTo(hx+3,hy+11,hx+5,hy+10); ctx.stroke();
    if (state === 'running') {
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.moveTo(hx-2,hy+9); ctx.lineTo(hx-1,hy+12); ctx.lineTo(hx,hy+9); ctx.fill();
      ctx.beginPath(); ctx.moveTo(hx+2,hy+9); ctx.lineTo(hx+1,hy+12); ctx.lineTo(hx,hy+9); ctx.fill();
    }
  }
};
})();
