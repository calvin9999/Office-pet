// ══════════════════════════════════════════════════════════════════
//  Furry Pets - 10 只独立形态宠物 (Part 1/2: 架构 + 前 3 只)
// ══════════════════════════════════════════════════════════════════

const P = 4.0;
const canvas = document.getElementById('pet-canvas');
const ctx = canvas ? canvas.getContext('2d') : null;

function clearCanvas() { if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height); }

function lightenColor(hex, amt) {
  let c = hex.replace('#', ''); if (c.length === 3) c = c[0]+c[0]+c[1]+c[1]+c[2]+c[2];
  const n = parseInt(c, 16);
  return `rgb(${Math.min(255,((n>>16)&0xFF)+amt)},${Math.min(255,((n>>8)&0xFF)+amt)},${Math.min(255,(n&0xFF)+amt)})`;
}
function darkenColor(hex, amt) {
  let c = hex.replace('#', ''); if (c.length === 3) c = c[0]+c[0]+c[1]+c[1]+c[2]+c[2];
  const n = parseInt(c, 16);
  return `rgb(${Math.max(0,((n>>16)&0xFF)-amt)},${Math.max(0,((n>>8)&0xFF)-amt)},${Math.max(0,(n&0xFF)-amt)})`;
}

function drawEye(ex, ey, size, col, look, blink) {
  const lx = (look && look.x) || 0, ly = (look && look.y) || 0;
  const b = blink === undefined ? 1 : blink;
  ctx.fillStyle = '#FFFEF8';
  ctx.beginPath(); ctx.ellipse(ex, ey, size, size*b, 0, 0, Math.PI*2); ctx.fill();
  if (b > 0.4) {
    const ir = size * 0.68;
    const g = ctx.createRadialGradient(ex+lx*2, ey+ly*2, 0.5, ex, ey, ir);
    g.addColorStop(0, lightenColor(col, 40)); g.addColorStop(0.7, col); g.addColorStop(1, darkenColor(col, 50));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(ex+lx, ey+ly, ir, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#1a1a1a'; ctx.beginPath(); ctx.arc(ex+lx*1.4, ey+ly*1.4, ir*0.45, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.95)';
    ctx.beginPath(); ctx.ellipse(ex-ir*0.3+lx, ey-ir*0.3+ly, ir*0.32, ir*0.24, -0.4, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.beginPath(); ctx.arc(ex+ir*0.25+lx, ey+ir*0.15+ly, ir*0.12, 0, Math.PI*2); ctx.fill();
  }
}
function drawSlitEye(ex, ey, size, col, look) {
  const lx = (look && look.x) || 0;
  ctx.fillStyle = '#FFFEF8';
  ctx.beginPath(); ctx.ellipse(ex, ey, size, size*0.9, 0, 0, Math.PI*2); ctx.fill();
  const g = ctx.createRadialGradient(ex, ey, 0.5, ex, ey, size*0.7);
  g.addColorStop(0, lightenColor(col, 40)); g.addColorStop(1, col);
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(ex+lx, ey, size*0.68, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath(); ctx.ellipse(ex+lx*1.3, ey, size*0.1, size*0.55, 0, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  ctx.beginPath(); ctx.ellipse(ex-size*0.2+lx, ey-size*0.2, size*0.2, size*0.15, -0.3, 0, Math.PI*2); ctx.fill();
}
function drawBlush(xL, xR, cy, a, sz) {
  sz = sz || 3;
  ctx.fillStyle = `rgba(255,120,140,${a||0.3})`;
  ctx.beginPath(); ctx.ellipse(xL, cy, sz, sz*0.65, 0, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(xR, cy, sz, sz*0.65, 0, 0, Math.PI*2); ctx.fill();
}
function drawNose(cx, cy, sz, col) {
  const g = ctx.createRadialGradient(cx-sz*0.15, cy-sz*0.15, 0.5, cx, cy, sz);
  g.addColorStop(0, lightenColor(col, 30)); g.addColorStop(1, col);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(cx, cy-sz*0.5);
  ctx.quadraticCurveTo(cx+sz*0.55, cy+sz*0.3, cx, cy+sz*0.45);
  ctx.quadraticCurveTo(cx-sz*0.55, cy+sz*0.3, cx, cy-sz*0.5);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  ctx.beginPath(); ctx.ellipse(cx-sz*0.13, cy-sz*0.13, sz*0.16, sz*0.1, -0.3, 0, Math.PI*2); ctx.fill();
}
function shadowOn(c) { ctx.shadowColor = darkenColor(c, 40); ctx.shadowBlur = 3; ctx.shadowOffsetY = 1; }
function shadowOff() { ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0; }

const furryPets = {};
window.__furryHelpers = { drawEye, drawSlitEye, drawBlush, drawNose, shadowOn, shadowOff, lightenColor, darkenColor, clearCanvas, canvas, ctx };
window.__furryPets = furryPets;
