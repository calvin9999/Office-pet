// ══ 后 5 只宠物：CINNA, BISCUIT, HONEY, SKYE, CLOVER ══
(function() {
const { drawEye, drawSlitEye, drawBlush, drawNose, shadowOn, shadowOff, canvas, ctx, clearCanvas, darkenColor } = window.__furryHelpers;
const furryPets = window.__furryPets;

// 6. CINNA - 萌系 Q 版小龙（大头胖身 + 小翅膀 + 大眼 + 腮红）
furryPets.cinna = {
  name: "Cinna · 龙崽", rarity: "UR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const breath = Math.sin(t*2.5)*0.7;
    const MAIN='#FF7B94', DARK='#C4425E', LIGHT='#FFB4C4', WHITE='#FFF0F4';
    const BELLY='#FFE0A8', GOLD='#FFD700', GREEN='#4ADE80';

    // —— 尾巴（圆滚带尖刺） ——
    const tailWag = Math.sin(t*3)*5;
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(cx+14, H-10);
    ctx.bezierCurveTo(cx+26+tailWag, H-12, cx+28+tailWag, H-22, cx+22+tailWag, H-26);
    ctx.bezierCurveTo(cx+16+tailWag, H-28, cx+10, H-22, cx+10, H-14);
    ctx.closePath(); ctx.fill();
    // 尾尖爱心
    ctx.fillStyle = GOLD;
    ctx.beginPath();
    const tx = cx+22+tailWag, ty = H-26;
    ctx.moveTo(tx, ty+2);
    ctx.bezierCurveTo(tx-3, ty-1, tx-4, ty-4, tx-1.5, ty-3);
    ctx.bezierCurveTo(tx, ty-2, tx, ty-2, tx+1.5, ty-3);
    ctx.bezierCurveTo(tx+4, ty-4, tx+3, ty-1, tx, ty+2);
    ctx.fill();

    // —— 小翅膀（背后 · 扇动） ——
    const flap = Math.sin(t*5)*0.3;
    // 左翅
    ctx.save();
    ctx.translate(cx-10, H/2+16+breath);
    ctx.rotate(-0.4 + flap);
    ctx.fillStyle = LIGHT;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-14, -6, -16, -14);
    ctx.quadraticCurveTo(-10, -8, -8, -4);
    ctx.quadraticCurveTo(-12, -10, -10, -14);
    ctx.quadraticCurveTo(-4, -8, -2, -4);
    ctx.lineTo(0, 0);
    ctx.fill();
    ctx.strokeStyle = DARK; ctx.lineWidth = 0.8;
    ctx.stroke();
    ctx.restore();
    // 右翅
    ctx.save();
    ctx.translate(cx+10, H/2+16+breath);
    ctx.rotate(0.4 - flap);
    ctx.fillStyle = LIGHT;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(14, -6, 16, -14);
    ctx.quadraticCurveTo(10, -8, 8, -4);
    ctx.quadraticCurveTo(12, -10, 10, -14);
    ctx.quadraticCurveTo(4, -8, 2, -4);
    ctx.lineTo(0, 0);
    ctx.fill();
    ctx.strokeStyle = DARK; ctx.lineWidth = 0.8;
    ctx.stroke();
    ctx.restore();

    // —— 胖短腿 ——
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.ellipse(cx-11, H-6, 5, 4, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+11, H-6, 5, 4, 0, 0, Math.PI*2); ctx.fill();
    // 脚爪（三指）
    ctx.fillStyle = GOLD;
    for (const ex of [-11, 11]) {
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.arc(cx+ex+i*1.8, H-2, 0.9, 0, Math.PI*2);
        ctx.fill();
      }
    }

    // —— 胖圆身体（西瓜形） ——
    shadowOn(DARK);
    const bg = ctx.createRadialGradient(cx-4, H/2+16+breath, 4, cx, H/2+20+breath, 20);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.6, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22+breath, 16, 15, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();

    // 金色肚皮（带鳞片分隔）
    ctx.fillStyle = BELLY;
    ctx.beginPath(); ctx.ellipse(cx, H/2+26+breath, 9, 10, 0, 0, Math.PI*2); ctx.fill();
    // 鳞片横纹
    ctx.strokeStyle = darkenColor(BELLY, 25); ctx.lineWidth = 0.8;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(cx-6, H/2+22+breath+i*3);
      ctx.quadraticCurveTo(cx, H/2+23+breath+i*3, cx+6, H/2+22+breath+i*3);
      ctx.stroke();
    }

    // 背刺（三角齿）
    ctx.fillStyle = GREEN;
    for (let i = -1; i <= 1; i++) {
      const sx = cx + i*6, sy = H/2+10+breath+Math.abs(i)*1;
      ctx.beginPath();
      ctx.moveTo(sx-2.5, sy+3);
      ctx.lineTo(sx, sy-3);
      ctx.lineTo(sx+2.5, sy+3);
      ctx.closePath(); ctx.fill();
    }

    // ═══ 大头（占比 > 身体） ═══
    const hx = cx, hy = H/2-6+breath*0.3;

    // 头本体
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-5, hy-6, 2, hx, hy, 20);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.65, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.arc(hx, hy, 19, 0, Math.PI*2); ctx.fill();
    shadowOff();

    // 脸颊白色圆块
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.arc(hx-11, hy+4, 5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+11, hy+4, 5, 0, Math.PI*2); ctx.fill();

    // 嘴部白色区域
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx, hy+6, 9, 7, 0, 0, Math.PI*2); ctx.fill();

    // —— 金色小角（Q 版，两个小尖） ——
    ctx.fillStyle = GOLD;
    // 左角
    ctx.beginPath();
    ctx.moveTo(hx-8, hy-16);
    ctx.quadraticCurveTo(hx-10, hy-24, hx-6, hy-26);
    ctx.quadraticCurveTo(hx-4, hy-22, hx-5, hy-15);
    ctx.closePath(); ctx.fill();
    // 角高光
    ctx.fillStyle = '#FFF0A0';
    ctx.beginPath();
    ctx.ellipse(hx-7, hy-20, 0.8, 3, 0.1, 0, Math.PI*2); ctx.fill();
    // 右角
    ctx.fillStyle = GOLD;
    ctx.beginPath();
    ctx.moveTo(hx+8, hy-16);
    ctx.quadraticCurveTo(hx+10, hy-24, hx+6, hy-26);
    ctx.quadraticCurveTo(hx+4, hy-22, hx+5, hy-15);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFF0A0';
    ctx.beginPath();
    ctx.ellipse(hx+7, hy-20, 0.8, 3, -0.1, 0, Math.PI*2); ctx.fill();

    // —— 小圆耳（在角旁边） ——
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.ellipse(hx-14, hy-12, 4, 5, -0.3, 0, Math.PI*2); ctx.fill();
    ctx.beginPath();
    ctx.ellipse(hx+14, hy-12, 4, 5, 0.3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = LIGHT;
    ctx.beginPath();
    ctx.ellipse(hx-14, hy-12, 1.8, 3, -0.3, 0, Math.PI*2); ctx.fill();
    ctx.beginPath();
    ctx.ellipse(hx+14, hy-12, 1.8, 3, 0.3, 0, Math.PI*2); ctx.fill();

    // —— 头顶呆毛（小小一撮） ——
    ctx.strokeStyle = DARK; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(hx, hy-18);
    ctx.quadraticCurveTo(hx+1, hy-23, hx-1, hy-25);
    ctx.stroke();

    // —— 超大星星眼 ——
    const blink = (t%4<0.15)?0.1:1;
    const lx = state==='running'?Math.sin(t*8)*0.5:Math.sin(t*1.5)*0.3;

    // 眼白
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx-7, hy-1, 5, 6*blink, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(hx+7, hy-1, 5, 6*blink, 0, 0, Math.PI*2); ctx.fill();

    if (blink > 0.5) {
      // 瞳孔（大紫色）
      const g1 = ctx.createRadialGradient(hx-7+lx, hy-1, 1, hx-7, hy-1, 4);
      g1.addColorStop(0, '#C084FC'); g1.addColorStop(1, '#6B21A8');
      ctx.fillStyle = g1;
      ctx.beginPath(); ctx.arc(hx-7+lx, hy-1, 3.5, 0, Math.PI*2); ctx.fill();
      const g2 = ctx.createRadialGradient(hx+7+lx, hy-1, 1, hx+7, hy-1, 4);
      g2.addColorStop(0, '#C084FC'); g2.addColorStop(1, '#6B21A8');
      ctx.fillStyle = g2;
      ctx.beginPath(); ctx.arc(hx+7+lx, hy-1, 3.5, 0, Math.PI*2); ctx.fill();

      // 星芒（四角星高光）
      const twinkle = Math.sin(t*4)*0.3+0.7;
      ctx.fillStyle = `rgba(255,255,255,${twinkle})`;
      for (const [ex, ey] of [[hx-7+lx, hy-1], [hx+7+lx, hy-1]]) {
        ctx.beginPath();
        ctx.moveTo(ex-2, ey-0.5);
        ctx.lineTo(ex-0.5, ey-0.5);
        ctx.lineTo(ex, ey-2.2);
        ctx.lineTo(ex+0.5, ey-0.5);
        ctx.lineTo(ex+2, ey-0.5);
        ctx.lineTo(ex+0.5, ey+0.5);
        ctx.lineTo(ex, ey+2.2);
        ctx.lineTo(ex-0.5, ey+0.5);
        ctx.closePath(); ctx.fill();
      }
      // 小高光
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.beginPath(); ctx.arc(hx-7+lx+1.2, hy-0.5, 0.7, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(hx+7+lx+1.2, hy-0.5, 0.7, 0, Math.PI*2); ctx.fill();
    }

    // 小鼻孔（两个点）
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.arc(hx-1.5, hy+6, 0.7, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+1.5, hy+6, 0.7, 0, Math.PI*2); ctx.fill();

    // —— 萌系嘴 ——
    if (state === 'running') {
      // 张嘴（吐小火焰）
      ctx.fillStyle = '#2A1010';
      ctx.beginPath(); ctx.ellipse(hx, hy+11, 3.5, 2.5, 0, 0, Math.PI*2); ctx.fill();
      // 小牙
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.moveTo(hx-1.5, hy+9); ctx.lineTo(hx-1, hy+11); ctx.lineTo(hx-0.5, hy+9); ctx.fill();
      ctx.beginPath(); ctx.moveTo(hx+0.5, hy+9); ctx.lineTo(hx+1, hy+11); ctx.lineTo(hx+1.5, hy+9); ctx.fill();
      // 小火焰
      ctx.fillStyle = '#FFD700';
      ctx.beginPath();
      ctx.moveTo(hx, hy+13);
      ctx.quadraticCurveTo(hx-2, hy+15, hx-1, hy+17);
      ctx.quadraticCurveTo(hx, hy+15, hx+1, hy+17);
      ctx.quadraticCurveTo(hx+2, hy+15, hx, hy+13);
      ctx.fill();
      ctx.fillStyle = '#FF6B35';
      ctx.beginPath();
      ctx.moveTo(hx, hy+13);
      ctx.quadraticCurveTo(hx-1, hy+14, hx, hy+16);
      ctx.quadraticCurveTo(hx+1, hy+14, hx, hy+13);
      ctx.fill();
    } else {
      // 萌系 3 字嘴
      ctx.strokeStyle = DARK; ctx.lineWidth = 1.2; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(hx-3, hy+9);
      ctx.quadraticCurveTo(hx-1.5, hy+11.5, hx, hy+10);
      ctx.quadraticCurveTo(hx+1.5, hy+11.5, hx+3, hy+9);
      ctx.stroke();
    }

    // 重重腮红（龙崽灵魂）
    drawBlush(hx-11, hx+11, hy+4, 0.55, 4);
  }
};

// 7. BISCUIT - 二哈（四腿站姿 + 白面具 + 永远吐舌）
furryPets.biscuit = {
  name: "Biscuit · 二哈", rarity: "SR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const wag = Math.sin(t*5)*6;
    const bounce = state==='running'?Math.abs(Math.sin(t*9))*2:0;
    const MAIN='#6B7889', DARK='#3A4554', LIGHT='#A8B4C0', WHITE='#F5F8FC';
    // 卷大尾
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(cx+16, H/2+14);
    ctx.bezierCurveTo(cx+26+wag, H/2+2, cx+24+wag, H/2-14, cx+10+wag, H/2-12);
    ctx.bezierCurveTo(cx+16+wag, H/2-4, cx+14, H/2+4, cx+12, H/2+14);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx+18+wag, H/2-2, 4, 8, -0.3+wag*0.03, 0, Math.PI*2); ctx.fill();
    // 四腿
    ctx.fillStyle = DARK;
    for (const bx of [-14,-4,3,9]) ctx.fillRect(cx+bx, H-15-bounce*0.4, 5, 13);
    ctx.fillStyle = WHITE;
    for (const bx of [-14,-4,3,9]) ctx.fillRect(cx+bx, H-5-bounce*0.4, 5, 3);
    // 身体
    shadowOn(DARK);
    const bg = ctx.createLinearGradient(cx, H/2, cx, H-10);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.5, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22-bounce, 17, 16, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(cx-6, H/2+16); ctx.lineTo(cx, H-8); ctx.lineTo(cx+6, H/2+16);
    ctx.quadraticCurveTo(cx, H/2+20, cx-6, H/2+16); ctx.fill();
    // 头
    const hx = cx, hy = H/2-2-bounce;
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-4, hy-4, 2, hx, hy, 17);
    hg.addColorStop(0, LIGHT); hg.addColorStop(1, MAIN);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.ellipse(hx, hy, 16, 15, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 白面具
    ctx.fillStyle = WHITE;
    ctx.beginPath();
    ctx.moveTo(hx, hy-12);
    ctx.quadraticCurveTo(hx-14, hy-8, hx-12, hy+2);
    ctx.quadraticCurveTo(hx-10, hy+14, hx, hy+14);
    ctx.quadraticCurveTo(hx+10, hy+14, hx+12, hy+2);
    ctx.quadraticCurveTo(hx+14, hy-8, hx, hy-12);
    ctx.fill();
    // 灰条
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(hx-3,hy-13); ctx.lineTo(hx-2,hy+2); ctx.lineTo(hx+2,hy+2); ctx.lineTo(hx+3,hy-13);
    ctx.closePath(); ctx.fill();
    // 立耳
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.moveTo(hx-14,hy-9); ctx.lineTo(hx-17,hy-22); ctx.lineTo(hx-8,hy-13); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+14,hy-9); ctx.lineTo(hx+17,hy-22); ctx.lineTo(hx+8,hy-13); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#FFB899';
    ctx.beginPath(); ctx.moveTo(hx-14,hy-12); ctx.lineTo(hx-16,hy-20); ctx.lineTo(hx-10,hy-14); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(hx+14,hy-12); ctx.lineTo(hx+16,hy-20); ctx.lineTo(hx+10,hy-14); ctx.closePath(); ctx.fill();
    // 冰蓝眼
    const lx = state==='running'?Math.sin(t*8)*0.7:0;
    drawEye(hx-7, hy-3, 4, '#3CB4DC', {x:lx, y:-0.2});
    drawEye(hx+7, hy-3, 4, '#3CB4DC', {x:lx, y:-0.2});
    // 眉斑
    ctx.fillStyle = DARK;
    ctx.beginPath(); ctx.ellipse(hx-7,hy-8,2,1.5,-0.4,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(hx+7,hy-8,2,1.5,0.4,0,Math.PI*2); ctx.fill();
    drawNose(hx, hy+4, 2.5, '#1a1a1a');
    // 永远吐舌
    const tx = Math.sin(t*8)*1.5;
    ctx.fillStyle = '#4A2020';
    ctx.beginPath(); ctx.ellipse(hx, hy+10, 5, 2.5, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#FF6B8A';
    ctx.beginPath(); ctx.ellipse(hx+tx, hy+12, 3, 3.5, 0, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = '#CC4060'; ctx.lineWidth = 0.6;
    ctx.beginPath(); ctx.moveTo(hx+tx,hy+10); ctx.lineTo(hx+tx,hy+15); ctx.stroke();
  }
};

// 8. HONEY - 胖棕熊（球形身 + 圆耳 + 小豆眼 + 大黑鼻）
furryPets.honey = {
  name: "Honey · 小熊", rarity: "SR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const breath = Math.sin(t*2)*0.5;
    const MAIN='#B8844C', DARK='#6B4518', LIGHT='#E0B88C', WHITE='#FFF0DC';
    // 球形身（大）
    shadowOn(DARK);
    const bg = ctx.createRadialGradient(cx-4, H/2+10, 3, cx, H/2+18, 24);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.5, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+20+breath, 22, 20, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 米黄肚
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx, H/2+26+breath, 12, 13, 0, 0, Math.PI*2); ctx.fill();
    // 胖短腿+掌垫
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.ellipse(cx-12, H-8, 7, 6, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx+12, H-8, 7, 6, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#5a3820';
    for (const xs of [-12, 12]) {
      ctx.beginPath(); ctx.ellipse(cx+xs, H-8, 4, 3, 0, 0, Math.PI*2); ctx.fill();
      for (let i=-1;i<=1;i++) {
        ctx.beginPath(); ctx.arc(cx+xs+i*2.2, H-10, 0.7, 0, Math.PI*2); ctx.fill();
      }
    }
    // 大圆头
    const hx = cx, hy = H/2-4+breath*0.3;
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-4, hy-5, 2, hx, hy, 19);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.arc(hx, hy, 18, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 圆耳
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.arc(hx-14,hy-14,6,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+14,hy-14,6,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = '#FFBFA8';
    ctx.beginPath(); ctx.arc(hx-14,hy-14,3,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(hx+14,hy-14,3,0,Math.PI*2); ctx.fill();
    // 米黄口鼻
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx, hy+6, 10, 8, 0, 0, Math.PI*2); ctx.fill();
    // 小黑豆眼（标志）
    const blink = (t%3.5<0.15)?0.2:1;
    ctx.fillStyle = '#1a1a1a';
    ctx.beginPath(); ctx.ellipse(hx-7, hy-3, 2.2, 2.2*blink, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(hx+7, hy-3, 2.2, 2.2*blink, 0, 0, Math.PI*2); ctx.fill();
    if (blink > 0.5) {
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.beginPath(); ctx.arc(hx-7.5, hy-3.5, 0.8, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(hx+6.5, hy-3.5, 0.8, 0, Math.PI*2); ctx.fill();
    }
    // 大黑鼻
    const ng = ctx.createRadialGradient(hx, hy+3, 1, hx, hy+3, 4);
    ng.addColorStop(0, '#444'); ng.addColorStop(1, '#1a1a1a');
    ctx.fillStyle = ng;
    ctx.beginPath(); ctx.ellipse(hx, hy+3, 4, 3, 0, 0, Math.PI*2); ctx.fill();
    // 嘴
    ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 1.3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(hx,hy+6); ctx.lineTo(hx,hy+10);
    ctx.moveTo(hx,hy+10); ctx.quadraticCurveTo(hx-3,hy+12,hx-5,hy+11);
    ctx.moveTo(hx,hy+10); ctx.quadraticCurveTo(hx+3,hy+12,hx+5,hy+11);
    ctx.stroke();
    drawBlush(hx-12, hx+12, hy+4, 0.4, 4);
  }
};

// 9. SKYE - 鹰头狮（鹰喙 + 冠羽 + 翅膀 + 鹰爪）
furryPets.skye = {
  name: "Skye · 凤翼", rarity: "SSR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const flap = Math.sin(t*4)*4;
    const MAIN='#5DADE2', DARK='#2E86C1', LIGHT='#AED6F1', WHITE='#F8FCFF', BEAK='#F39C12', CREST='#F9E79F';
    // 翅膀
    ctx.fillStyle = DARK;
    ctx.beginPath();
    ctx.moveTo(cx-16, H/2+18);
    ctx.quadraticCurveTo(cx-30, H/2+10-flap, cx-24, H/2-6);
    ctx.quadraticCurveTo(cx-12, H/2+4, cx-14, H/2+20); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx+16, H/2+18);
    ctx.quadraticCurveTo(cx+30, H/2+10-flap, cx+24, H/2-6);
    ctx.quadraticCurveTo(cx+12, H/2+4, cx+14, H/2+20); ctx.fill();
    ctx.fillStyle = MAIN;
    ctx.beginPath();
    ctx.moveTo(cx-14, H/2+18);
    ctx.quadraticCurveTo(cx-24, H/2+12-flap, cx-20, H/2+2);
    ctx.quadraticCurveTo(cx-10, H/2+8, cx-12, H/2+20); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx+14, H/2+18);
    ctx.quadraticCurveTo(cx+24, H/2+12-flap, cx+20, H/2+2);
    ctx.quadraticCurveTo(cx+10, H/2+8, cx+12, H/2+20); ctx.fill();
    // 狮身
    shadowOn(DARK);
    const bg = ctx.createLinearGradient(cx, H/2+10, cx, H-6);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.5, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22, 15, 16, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 鹰爪
    ctx.fillStyle = BEAK;
    for (const ex of [-9, 9]) for (let i=-1;i<=1;i++) {
      ctx.fillRect(cx+ex+i*1.5-0.5, H-8, 1, 5);
    }
    const hx = cx, hy = H/2-4;
    // 冠羽
    ctx.fillStyle = CREST;
    for (let i=-2;i<=2;i++) {
      const a = -Math.PI/2 + i*0.2, len = 10 + Math.abs(i)*1.5;
      ctx.beginPath();
      ctx.moveTo(hx+i*1.5, hy-14);
      ctx.lineTo(hx+i*1.5+Math.cos(a)*len, hy-14+Math.sin(a)*len);
      ctx.lineTo(hx+i*1.5+2, hy-14);
      ctx.closePath(); ctx.fill();
    }
    // 头
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-3, hy-4, 2, hx, hy, 16);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.ellipse(hx, hy, 15, 14, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 白脸
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx, hy+2, 11, 11, 0, 0, Math.PI*2); ctx.fill();
    // 鹰喙
    ctx.fillStyle = BEAK;
    ctx.beginPath();
    ctx.moveTo(hx-3, hy+5); ctx.lineTo(hx, hy+13); ctx.lineTo(hx+3, hy+5);
    ctx.quadraticCurveTo(hx, hy+8, hx-3, hy+5); ctx.fill();
    ctx.strokeStyle = darkenColor(BEAK, 40); ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.moveTo(hx-3,hy+8); ctx.lineTo(hx+3,hy+8); ctx.stroke();
    // 红鹰眼
    const blink = (t%3<0.1)?0.1:1;
    const lx = Math.sin(t*1.2)*0.5;
    drawEye(hx-7, hy-2, 3.8, '#E74C3C', {x:lx, y:0}, blink);
    drawEye(hx+7, hy-2, 3.8, '#E74C3C', {x:lx, y:0}, blink);
    // 眼周黑纹
    ctx.strokeStyle = DARK; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(hx-11,hy-3); ctx.quadraticCurveTo(hx-8,hy-6,hx-4,hy-4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(hx+11,hy-3); ctx.quadraticCurveTo(hx+8,hy-6,hx+4,hy-4); ctx.stroke();
  }
};

// 10. CLOVER - 精灵鹿（鹿角 + 梅花斑 + 细腿 + 翠绿眼）
furryPets.clover = {
  name: "Clover · 精灵鹿", rarity: "SR",
  draw: function(state, t) {
    const W = canvas.width, H = canvas.height, cx = W/2;
    clearCanvas();
    const bounce = state==='running'?Math.abs(Math.sin(t*8))*3:Math.sin(t*2)*0.5;
    const MAIN='#D4A574', DARK='#8B6028', LIGHT='#F0D4A0', WHITE='#FFF5E8', SPOT='#FFFFFF';
    // 细长腿（4条）
    ctx.fillStyle = DARK;
    ctx.fillRect(cx-13, H-16-bounce*0.5, 3, 14);
    ctx.fillRect(cx-5, H-16-bounce*0.5, 3, 14);
    ctx.fillRect(cx+2, H-16-bounce*0.5, 3, 14);
    ctx.fillRect(cx+10, H-16-bounce*0.5, 3, 14);
    // 白色蹄尖
    ctx.fillStyle = '#3a2410';
    for (const bx of [-13,-5,2,10]) ctx.fillRect(cx+bx, H-4-bounce*0.5, 3, 2);
    // 短尾
    ctx.fillStyle = MAIN;
    ctx.beginPath(); ctx.ellipse(cx+14, H/2+18-bounce, 3, 5, -0.3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx+15, H/2+20-bounce, 2, 3, 0, 0, Math.PI*2); ctx.fill();
    // 优雅长身
    shadowOn(DARK);
    const bg = ctx.createLinearGradient(cx-14, H/2+8, cx+14, H-6);
    bg.addColorStop(0, LIGHT); bg.addColorStop(0.5, MAIN); bg.addColorStop(1, DARK);
    ctx.fillStyle = bg;
    ctx.beginPath(); ctx.ellipse(cx, H/2+22-bounce, 14, 13, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 梅花斑（标志！）
    ctx.fillStyle = SPOT; ctx.globalAlpha = 0.7;
    for (const [sx,sy,sr] of [[-6,18,1.5],[5,15,1.8],[-3,24,1.2],[8,22,1.4],[-9,22,1.2],[2,28,1.3]]) {
      ctx.beginPath(); ctx.arc(cx+sx, H/2+sy-bounce, sr, 0, Math.PI*2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // 白肚
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(cx, H/2+28-bounce, 5, 4, 0, 0, Math.PI*2); ctx.fill();
    // 头
    const hx = cx, hy = H/2-bounce;
    // 鹿角（分枝金色）
    ctx.strokeStyle = '#C0A070'; ctx.lineWidth = 1.8; ctx.lineCap = 'round';
    // 左角
    ctx.beginPath();
    ctx.moveTo(hx-8, hy-10);
    ctx.lineTo(hx-11, hy-24);
    ctx.moveTo(hx-9, hy-16); ctx.lineTo(hx-16, hy-20);
    ctx.moveTo(hx-10, hy-20); ctx.lineTo(hx-15, hy-26);
    ctx.moveTo(hx-11, hy-24); ctx.lineTo(hx-7, hy-28);
    ctx.stroke();
    // 右角
    ctx.beginPath();
    ctx.moveTo(hx+8, hy-10);
    ctx.lineTo(hx+11, hy-24);
    ctx.moveTo(hx+9, hy-16); ctx.lineTo(hx+16, hy-20);
    ctx.moveTo(hx+10, hy-20); ctx.lineTo(hx+15, hy-26);
    ctx.moveTo(hx+11, hy-24); ctx.lineTo(hx+7, hy-28);
    ctx.stroke();
    // 头本体（长椭圆鹿脸）
    shadowOn(DARK);
    const hg = ctx.createRadialGradient(hx-3, hy-4, 2, hx, hy, 15);
    hg.addColorStop(0, LIGHT); hg.addColorStop(0.7, MAIN); hg.addColorStop(1, DARK);
    ctx.fillStyle = hg;
    ctx.beginPath(); ctx.ellipse(hx, hy+2, 13, 14, 0, 0, Math.PI*2); ctx.fill();
    shadowOff();
    // 鹿耳（长椭圆侧展）
    ctx.fillStyle = MAIN;
    ctx.save();
    ctx.translate(hx-14, hy-6); ctx.rotate(-0.6);
    ctx.beginPath(); ctx.ellipse(0,0,4,8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = '#FFD4B4';
    ctx.beginPath(); ctx.ellipse(0,0,2,6,0,0,Math.PI*2); ctx.fill();
    ctx.restore();
    ctx.fillStyle = MAIN;
    ctx.save();
    ctx.translate(hx+14, hy-6); ctx.rotate(0.6);
    ctx.beginPath(); ctx.ellipse(0,0,4,8,0,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = '#FFD4B4';
    ctx.beginPath(); ctx.ellipse(0,0,2,6,0,0,Math.PI*2); ctx.fill();
    ctx.restore();
    // 白口鼻
    ctx.fillStyle = WHITE;
    ctx.beginPath(); ctx.ellipse(hx, hy+7, 7, 5, 0, 0, Math.PI*2); ctx.fill();
    // 翠绿大眼
    const blink = (t%3<0.1)?0.15:1;
    drawEye(hx-6, hy-1, 3.8, '#6B8E23', {x:Math.sin(t)*0.4,y:0}, blink);
    drawEye(hx+6, hy-1, 3.8, '#6B8E23', {x:Math.sin(t)*0.4,y:0}, blink);
    // 睫毛（鹿的温柔感）
    ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 0.8;
    for (let i=-1;i<=1;i++) {
      ctx.beginPath(); ctx.moveTo(hx-6+i, hy-5); ctx.lineTo(hx-6+i-1, hy-7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(hx+6+i, hy-5); ctx.lineTo(hx+6+i+1, hy-7); ctx.stroke();
    }
    drawNose(hx, hy+6, 2, '#6B3820');
    ctx.strokeStyle = '#3a2410'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(hx,hy+8); ctx.lineTo(hx,hy+10);
    ctx.moveTo(hx,hy+10); ctx.quadraticCurveTo(hx-2,hy+12,hx-4,hy+11);
    ctx.moveTo(hx,hy+10); ctx.quadraticCurveTo(hx+2,hy+12,hx+4,hy+11); ctx.stroke();
    drawBlush(hx-10, hx+10, hy+4, 0.3, 3);
  }
};

// ═══════════════════════════════════════════════════════════════════
//  ANIMATION ENGINE
// ═══════════════════════════════════════════════════════════════════

window.pets = furryPets;
window.furryPets = furryPets;

const UNLOCK_CONDITIONS = {
  rex:      { unlocked: true },
  amber:    { unlocked: true },
  mochi:    { unlocked: true },
  luna:     { requirement: 'conversations >= 10', desc: '累计对话 10 次', check: (s) => s.totalConversations >= 10 },
  midnight: { requirement: 'conversations >= 20', desc: '累计对话 20 次', check: (s) => s.totalConversations >= 20 },
  cinna:    { requirement: 'conversations >= 40', desc: '累计对话 40 次', check: (s) => s.totalConversations >= 40 },
  biscuit:  { requirement: 'daily >= 8',  desc: '单日对话 ≥ 8 次', check: (s) => s.todayConversations >= 8 },
  honey:    { requirement: 'streak >= 3', desc: '连续 3 天使用', check: (s) => s.streak >= 3 },
  skye:     { requirement: 'daily >= 12', desc: '单日对话 ≥ 12 次', check: (s) => s.todayConversations >= 12 },
  clover:   { requirement: 'streak >= 5', desc: '连续 5 天使用', check: (s) => s.streak >= 5 },
};

let unlockedPets = new Set(['rex', 'amber', 'mochi']);
const petKeys = Object.keys(furryPets);
let currentPet = localStorage.getItem('office-pet-furry') || 'rex';
if (!furryPets[currentPet]) currentPet = 'rex';
let currentState = 'idle';
let animTimer = null;
let startTime = Date.now();

function renderFrame() {
  const pet = furryPets[currentPet];
  if (!pet || !pet.draw) return;
  const t = (Date.now() - startTime) / 1000;
  pet.draw(currentState, t);
}
function startAnimation() {
  if (animTimer) cancelAnimationFrame(animTimer);
  function loop() {
    renderFrame();
    animTimer = requestAnimationFrame(loop);
  }
  loop();
}
function setPetState(state) {
  if (!furryPets[currentPet]) return;
  currentState = state;
  startTime = Date.now();
}
function switchPet(key) {
  if (key && furryPets[key]) {
    if (!isPetUnlocked(key)) return currentPet;
    currentPet = key;
  } else {
    const unlockedKeys = petKeys.filter(k => isPetUnlocked(k));
    if (unlockedKeys.length === 0) return currentPet;
    const idx = unlockedKeys.indexOf(currentPet);
    currentPet = unlockedKeys[(idx + 1) % unlockedKeys.length];
  }
  localStorage.setItem('office-pet-furry', currentPet);
  startTime = Date.now();
  return currentPet;
}
function isPetUnlocked(key) { return unlockedPets.has(key); }
function tryUnlockPet(key) {
  if (isPetUnlocked(key)) return;
  unlockedPets.add(key);
  fetch('http://127.0.0.1:13121/unlock', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({pet:key}) }).catch(()=>{});
}
function loadUnlockedPets() {
  return fetch('http://127.0.0.1:13121/unlocks').then(r=>r.json()).then(data => {
    if (data.unlockedPets) unlockedPets = new Set(data.unlockedPets.filter(k => furryPets[k]));
  }).catch(()=>{});
}
function getLockedPetInfo(key) {
  const cond = UNLOCK_CONDITIONS[key];
  if (!cond || cond.unlocked) return null;
  return { name: furryPets[key].name, desc: cond.desc, rarity: furryPets[key].rarity };
}

if (canvas) {
  canvas.title = '单击撸宠 · 双击切换';
  let lastClickTime = 0; let clickTimeout = null;
  canvas.addEventListener('click', (e) => {
    e.stopPropagation();
    const now = Date.now();
    if (now - lastClickTime < 350) {
      clearTimeout(clickTimeout); lastClickTime = 0;
      const name = switchPet();
      canvas.title = furryPets[name].name + ' (单击撸宠)';
      if (window.showPetName) window.showPetName(furryPets[name].name, furryPets[name].rarity);
    } else {
      lastClickTime = now;
      clickTimeout = setTimeout(() => {
        if (window.onPetTouch) window.onPetTouch();
        lastClickTime = 0;
      }, 350);
    }
  });
  canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault(); e.stopPropagation();
    if (window.showFeedMenu) window.showFeedMenu(e);
  });
}

startAnimation();
loadUnlockedPets();

window.setPetState = setPetState;
window.switchPet = switchPet;
window.getCurrentPet = () => currentPet;
window.isPetUnlocked = isPetUnlocked;
window.tryUnlockPet = tryUnlockPet;
window.UNLOCK_CONDITIONS = UNLOCK_CONDITIONS;
window.unlockedPets = unlockedPets;
window.getLockedPetInfo = getLockedPetInfo;
window.loadUnlockedPets = loadUnlockedPets;
})();
