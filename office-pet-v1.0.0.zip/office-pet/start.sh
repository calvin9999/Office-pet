#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 启动脚本
# ──────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/.pet.pid"
PORT=13121

# 检查是否已经在运行
if [ -f "$PID_FILE" ]; then
  OLD_PID=$(cat "$PID_FILE")
  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "🐾 Office Pet 已经在运行中 (PID: $OLD_PID)"
    echo "   访问 http://127.0.0.1:$PORT/health 检查状态"
    echo "   使用 ./stop.sh 停止"
    exit 0
  else
    rm -f "$PID_FILE"
  fi
fi

echo "🐾 正在启动 Office Pet..."
cd "$SCRIPT_DIR"
nohup npx electron . > "$SCRIPT_DIR/.pet.log" 2>&1 &
PET_PID=$!
echo "$PET_PID" > "$PID_FILE"

# 等待服务器就绪
for i in {1..10}; do
  sleep 1
  if curl -s "http://127.0.0.1:$PORT/health" > /dev/null 2>&1; then
    echo "✅ Office Pet 已启动! (PID: $PET_PID)"
    echo "   通知接口: http://127.0.0.1:$PORT/notify"
    echo "   健康检查: http://127.0.0.1:$PORT/health"
    echo ""
    echo "   停止命令: $SCRIPT_DIR/stop.sh"
    exit 0
  fi
done

echo "⚠️  启动可能未完全就绪，请稍等片刻后检查..."
echo "   PID: $PET_PID"
echo "   日志: $SCRIPT_DIR/.pet.log"
