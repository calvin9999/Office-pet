#!/bin/bash
# Office Pet Hook: Stop → 通知桌面宠物任务完成
INPUT=$(cat)

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

eval "$(echo "$INPUT" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print('SESSION_ID=\"' + d.get('session_id', '') + '\"')
    print('STOP_REASON=\"' + d.get('stop_reason', '') + '\"')
except: pass
" 2>/dev/null)"

# 根据原因构造消息（随机趣味文案）
DONE_MSGS=(
  "通关！"
  "任务完成！"
  "任务已完成，长官"
  "又是生产力爆棚的一天"
  "什么 Bug？不存在的"
  "完美落地 ✌️"
  "搞定！下一个？"
  "成就解锁！"
  "+1 经验值"
  "全部通过！"
)
WARN_MSGS=(
  "话太多说不完了..."
  "字数爆表，下回继续"
  "额度不够用了"
)

case "$STOP_REASON" in
  end_turn|stop_sequence)
    IDX=$((RANDOM % ${#DONE_MSGS[@]}))
    MSG="${DONE_MSGS[$IDX]}"
    ;;
  max_tokens)
    IDX=$((RANDOM % ${#WARN_MSGS[@]}))
    MSG="${WARN_MSGS[$IDX]}"
    ;;
  *)
    IDX=$((RANDOM % ${#DONE_MSGS[@]}))
    MSG="${DONE_MSGS[$IDX]}"
    ;;
esac

curl -s --max-time 2 -X POST "${PET_URL}/notify" \
  -H "Content-Type: application/json" \
  -d "{\"title\":\"Office Pet\",\"message\":\"$MSG\",\"type\":\"done\",\"session_id\":\"$SESSION_ID\"}" \
  >/dev/null 2>&1

echo '{}'
