#!/bin/bash
# Office Pet Hook: UserPromptSubmit → 通知桌面宠物开始计时
INPUT=$(cat)

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

# 提取 session_id、workspace 和用户描述
EVAL_OUTPUT=$(echo "$INPUT" | python3 -c '
import sys, json, os
try:
    d = json.load(sys.stdin)
    sid = d.get("session_id", "")
    # 尝试多种字段获取工作区路径
    ws = ""
    for k in ("workspace", "cwd", "workspaceFolder", "rootPath"):
        v = d.get(k, "")
        if isinstance(v, str) and v.strip():
            ws = v.strip()
            break
    if not ws:
        ws = os.environ.get("PWD", "")
    label = os.path.basename(ws) if ws else ""
    # 从 conversation 名称或标题获取标签
    if not label:
        for k in ("conversationTitle", "title", "name"):
            v = d.get(k, "")
            if isinstance(v, str) and v.strip():
                label = v.strip()[:20]
                break
    desc = ""
    for key in ("prompt", "message", "user_prompt", "question"):
        val = d.get(key, "")
        if isinstance(val, str) and val.strip():
            desc = val.strip().replace("\"", "").replace("\\", "")[:10]
            break
    def sh_esc(v):
        return v.replace("\"", "\\\"")
    print("SESSION_ID=\"" + sh_esc(sid) + "\"")
    print("WORKSPACE=\"" + sh_esc(ws) + "\"")
    print("WS_LABEL=\"" + sh_esc(label) + "\"")
    print("DESC=\"" + sh_esc(desc) + "\"")
except Exception:
    pass
' 2>/dev/null)

eval "$EVAL_OUTPUT"

if [ -z "$SESSION_ID" ]; then
  SESSION_ID="s$$"
fi
if [ -z "$WS_LABEL" ]; then
  WS_LABEL="$(basename "$PWD" 2>/dev/null || echo 'session')"
  WORKSPACE="${PWD:-}"
fi

curl -s --max-time 2 -X POST "${PET_URL}/start" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"$SESSION_ID\",\"workspace\":\"$WORKSPACE\",\"workspace_label\":\"$WS_LABEL\",\"description\":\"$DESC\"}" \
  >/dev/null 2>&1

echo '{}'
