#!/bin/bash
# Office Pet Hook: PostToolUse → 文件编辑实时统计（带 session_id）
INPUT=$(cat)

# Detect pet host (remote or local)
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

# 提取 file_path 和 session_id
eval "$(echo "$INPUT" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    sid = d.get('session_id', '')
    inp = d.get('tool_input', d.get('input', {}))
    fp = ''
    if isinstance(inp, dict):
        fp = inp.get('file_path', inp.get('filePath', ''))
    print('SESSION_ID=\"' + sid + '\"')
    print('FILE_PATH=\"' + fp + '\"')
except: pass
" 2>/dev/null)"

if [ -n "$FILE_PATH" ]; then
  curl -s --max-time 2 -X POST "${PET_URL}/stats" \
    -H "Content-Type: application/json" \
    -d "{\"file\":\"$FILE_PATH\",\"session_id\":\"$SESSION_ID\"}" \
    >/dev/null 2>&1
fi

echo '{}'
