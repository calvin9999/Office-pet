#!/bin/bash
# Office Pet Hook: Notification → LLM 回复字数统计（带 session_id）
INPUT=$(cat)

# Detect pet host (remote or local)
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

# 统计回复文本长度和提取 session_id
eval "$(echo "$INPUT" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    sid = d.get('session_id', '')
    text = d.get('response', d.get('text', d.get('message', '')))
    chars = len(text) if isinstance(text, str) else 0
    print('SESSION_ID=\"' + sid + '\"')
    print('CHARS=' + str(chars))
except:
    print('CHARS=0')
" 2>/dev/null)"

if [ -n "$CHARS" ] && [ "$CHARS" -gt 0 ] 2>/dev/null; then
  curl -s --max-time 2 -X POST "${PET_URL}/stats" \
    -H "Content-Type: application/json" \
    -d "{\"chars\":$CHARS,\"session_id\":\"$SESSION_ID\"}" \
    >/dev/null 2>&1
fi

echo '{}'
