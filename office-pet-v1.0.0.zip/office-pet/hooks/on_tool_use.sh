#!/bin/bash
# Office Pet Hook: PreToolUse → 标记等待授权 + 危险命令检测
INPUT=$(cat)

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

eval "$(echo "$INPUT" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    sid = d.get('session_id', '')
    tool = d.get('tool_name', '')
    inp = d.get('tool_input', d.get('input', {}))
    cmd = ''
    if isinstance(inp, str):
        cmd = inp
    elif isinstance(inp, dict):
        cmd = inp.get('command', inp.get('content', ''))
    print('SESSION_ID=\"' + sid + '\"')
    print('TOOL_NAME=\"' + str(tool) + '\"')
    print('CMD=\"' + str(cmd).replace('\"', '\\\\\"')[:200] + '\"')
except: pass
" 2>/dev/null)"

# Mark session as waiting_approval (user needs to click confirm)
if [ -n "$SESSION_ID" ]; then
  curl -s --max-time 2 -X POST "${PET_URL}/session-status" \
    -H "Content-Type: application/json" \
    -d "{\"session_id\":\"$SESSION_ID\",\"status\":\"waiting_approval\"}" \
    >/dev/null 2>&1
fi

# 危险命令检测
DANGER=0
case "$CMD" in
  *"rm -rf /"*|*"rm -rf ~"*|*"mkfs"*|*"dd if="*|*"> /dev/sda"*|*"chmod -R 777 /"*)
    DANGER=1 ;;
esac

if [ "$DANGER" = "1" ]; then
  curl -s --max-time 2 -X POST "${PET_URL}/notify" \
    -H "Content-Type: application/json" \
    -d "{\"title\":\"⚠️ 危险命令\",\"message\":\"检测到高风险操作！\",\"type\":\"error\",\"session_id\":\"$SESSION_ID\"}" \
    >/dev/null 2>&1
  afplay /System/Library/Sounds/Basso.aiff &>/dev/null &
fi

echo '{}'
