#!/bin/bash
# Office Pet Hook: PostToolUse → 工具执行完毕，恢复 session 为 running
INPUT=$(cat)

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "$SCRIPT_DIR/.pet-host" ]; then
  PET_HOST="$(cat "$SCRIPT_DIR/.pet-host")"
else
  PET_HOST="127.0.0.1"
fi
PET_URL="http://${PET_HOST}:13121"

SESSION_ID=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print(d.get('session_id', ''))
except: pass
" 2>/dev/null)

if [ -n "$SESSION_ID" ]; then
  curl -s --max-time 2 -X POST "${PET_URL}/session-status" \
    -H "Content-Type: application/json" \
    -d "{\"session_id\":\"$SESSION_ID\",\"status\":\"running\"}" \
    >/dev/null 2>&1
fi

echo '{}'
