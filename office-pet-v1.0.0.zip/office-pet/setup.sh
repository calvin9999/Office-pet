#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 配置脚本（配合 .app 使用）
#
#  将 Office Pet.app 拖入 Applications 后运行此脚本：
#    bash setup.sh
#
#  自动完成：Hook 配置 + Skill 安装 + 开机自启
# ──────────────────────────────────────────────

set -e

APP_PATH="/Applications/Office Pet.app"
RESOURCES="$APP_PATH/Contents/Resources"
HOOKS_DIR="$RESOURCES/hooks"
SKILL_DIR="$RESOURCES/skill"
SETTINGS_FILE="$HOME/.codebuddy/settings.json"

echo "🐾 Office Pet 配置"
echo "====================="
echo ""

# ── 检查 App 是否已安装 ──────────────────────
if [ ! -d "$APP_PATH" ]; then
  echo "❌ 未找到 Office Pet.app"
  echo "   请先将 Office Pet.app 拖入 /Applications"
  exit 1
fi
echo "✅ 找到 $APP_PATH"
echo ""

# ── 复制 Hooks 到用户目录（避免权限问题） ──────
PET_HOME="$HOME/.office-pet"
mkdir -p "$PET_HOME/hooks"

if [ -d "$HOOKS_DIR" ]; then
  cp "$HOOKS_DIR/"*.sh "$PET_HOME/hooks/"
  chmod +x "$PET_HOME/hooks/"*.sh
  echo "✅ Hook 脚本已复制到 $PET_HOME/hooks/"
else
  echo "❌ 未找到 hooks 目录"
  exit 1
fi
echo ""

# ── 配置 Hooks ─────────────────────
echo "🔗 配置 Hooks..."
mkdir -p "$HOME/.codebuddy"

HOOK_DIR="$PET_HOME/hooks"

if [ ! -f "$SETTINGS_FILE" ]; then
  cat > "$SETTINGS_FILE" << ENDJSON
{
  "hooks": {
    "UserPromptSubmit": [
      { "matcher": "", "hooks": [{ "type": "command", "command": "$HOOK_DIR/on_start.sh", "timeout": 5 }] }
    ],
    "PreToolUse": [
      { "matcher": "Bash|execute_command", "hooks": [{ "type": "command", "command": "$HOOK_DIR/on_tool_use.sh", "timeout": 5 }] }
    ],
    "Stop": [
      { "matcher": "", "hooks": [{ "type": "command", "command": "$HOOK_DIR/on_finish.sh", "timeout": 5 }] }
    ]
  }
}
ENDJSON
  echo "   ✅ 已创建 $SETTINGS_FILE"
else
  if python3 -c "
import json, sys
with open('$SETTINGS_FILE') as f: d = json.load(f)
if 'hooks' in d and 'Stop' in d.get('hooks', {}): sys.exit(0)
sys.exit(1)
" 2>/dev/null; then
    echo "   ⚠️  已有 hooks 配置，跳过"
  else
    python3 -c "
import json
with open('$SETTINGS_FILE') as f: d = json.load(f)
d.setdefault('hooks', {})
hd = '$HOOK_DIR'
d['hooks']['UserPromptSubmit'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{hd}/on_start.sh', 'timeout': 5}]}]
d['hooks']['PreToolUse'] = [{'matcher': 'Bash|execute_command', 'hooks': [{'type': 'command', 'command': f'{hd}/on_tool_use.sh', 'timeout': 5}]}]
d['hooks']['Stop'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{hd}/on_finish.sh', 'timeout': 5}]}]
with open('$SETTINGS_FILE', 'w') as f: json.dump(d, f, indent=2, ensure_ascii=False)
" 2>/dev/null
    echo "   ✅ 已合并 hooks"
  fi
fi
echo ""

# ── 安装 Skill ───────────────────────────────
echo "🧠 安装 Skill..."
SKILL_DST="$HOME/.codebuddy/skills/office-pet"
if [ -d "$SKILL_DIR" ]; then
  mkdir -p "$HOME/.codebuddy/skills"
  rm -rf "$SKILL_DST"
  cp -r "$SKILL_DIR" "$SKILL_DST"
  chmod +x "$SKILL_DST/scripts/"*.sh 2>/dev/null
  echo "   ✅ Skill 已安装"
else
  echo "   ⚠️  未找到 skill 目录，跳过"
fi
echo ""

# ── 配置开机自启 ─────────────────────────────
echo "⚡ 配置开机自启..."
PLIST="$HOME/Library/LaunchAgents/com.office.pet.plist"
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.office.pet</string>
    <key>ProgramArguments</key>
    <array>
        <string>$APP_PATH/Contents/MacOS/Office Pet</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>
EOF

launchctl unload "$PLIST" 2>/dev/null
launchctl load "$PLIST"
echo "   ✅ 开机自启已配置"
echo ""

# ── 启动应用 ─────────────────────────────────
echo "🚀 启动 Office Pet..."
open "$APP_PATH"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎉 配置完成！"
echo ""
echo "   宠物已在屏幕右上角出现"
echo "   在客户端中发送消息即可体验"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
