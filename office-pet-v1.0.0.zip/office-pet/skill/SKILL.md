---
name: office-pet
description: >
  This skill manages the Office Pet desktop companion -- a furry-style pet that lives on your screen
  and reacts to AI assistant activity. Works with both CodeBuddy and WorkBuddy clients.
  Use this skill when the user wants to install, configure, troubleshoot, customize,
  or extend the Office Pet application.
  Trigger phrases include "pet", "desktop pet", "furry pet", "办公宠物", "宠物", "桌面宠物", "Office Pet".
  Also use when the user asks about pet features like feeding, unlocking pets, mood system, or touch interactions.
---

# Office Pet Skill

Manage the Office Pet desktop companion application -- compatible with both CodeBuddy and WorkBuddy clients.

## Overview

Office Pet is an Electron-based furry-style desktop pet that sits on the macOS desktop as a Dynamic Island
style pill. It integrates with AI assistant clients through Hooks to automatically track task progress,
display notifications, and provide interactive features like feeding, touch reactions, and pet collection.

**Project location**: `~/office-pet/`
**Config files** (dual-write):
- `~/.codebuddy/settings.json` -- used by CodeBuddy client
- `~/.workbuddy/settings.json` -- used by WorkBuddy client
**Data**: `~/.office-pet-stats/` (daily JSON stats + unlocks.json)
**Service**: `http://127.0.0.1:13121`

## Dual-Client Compatibility

Both CodeBuddy and WorkBuddy share the same hook script format and point to the same set of
bash scripts (`~/office-pet/hooks/*`) and the same local Pet service. The installation
scripts write hook configuration into **both** config files simultaneously so that either
client can trigger the pet.

| Client | Config Path | Status after install |
|--------|------------|---------------------|
| CodeBuddy | `~/.codebuddy/settings.json` | Hooks written |
| WorkBuddy | `~/.workbuddy/settings.json` | Hooks written |

No special operation is required from users. Run `install.sh` once, and both clients work.

If migrating from an old CodeBuddy-only installation, run:
```bash
bash ~/office-pet/install-hooks.sh
```

## Installation

### Full Install (local Mac)

```bash
cd ~/office-pet
bash install.sh
```

Automatically handles:
1. Prerequisites check (Node.js >= 18, Python 3)
2. npm install
3. Script permissions
4. Dual-write Hook config into **both** `~/.codebuddy/settings.json` and `~/.workbuddy/settings.json`
5. Skill deployment to `~/.codebuddy/skills/office-pet/`
6. LaunchAgent auto-start registration
7. Start the pet

### Cloud Dev Environment (lightweight)

```bash
bash ~/office-pet/install-hooks.sh
```

Only writes hook configs (no Electron/npm needed). Pet runs on local Mac.

## Architecture

- **main.js**: Electron main process + Express HTTP server (port 13121) + WebSocket
- **renderer/**: HTML/CSS/JS rendered in a transparent Electron window
- **hooks/**: bash scripts triggered by client lifecycle events
- **Data flow**: Client Hook -> bash script -> HTTP POST -> Express -> WebSocket -> renderer

## Hook Configuration

Hooks map client events to pet actions:

| Hook Event | Script | Action |
|-----------|--------|--------|
| `UserPromptSubmit` | `on_start.sh` | Create session, start timer |
| `PreToolUse` | `on_tool_use.sh` | Mark waiting_approval; detect dangerous commands |
| `PostToolUse` | `on_tool_done.sh` | Resume running status |
| `Stop` | `on_finish.sh` | End timer, show notification + sound |

To update hook paths after moving the project (updates both config files):

```bash
# Replace OLD_PATH with new path in BOTH settings files
for f in "$HOME/.codebuddy/settings.json" "$HOME/.workbuddy/settings.json"; do
  python3 -c "
import json
with open('$f') as fh: d = json.load(fh)
for event in d.get('hooks', {}).values():
    for rule in event:
        for h in rule.get('hooks', []):
            h['command'] = h['command'].replace('OLD_PATH', 'NEW_PATH')
with open('$f', 'w') as fh: json.dump(d, fh, indent=2)
"
done
```

## Quick Operations via Script

```bash
bash ~/office-pet/scripts/pet-ctl.sh <command>
```

| Command | Action |
|---------|--------|
| `start` | Start the pet |
| `stop` | Stop the pet |
| `restart` | Restart the pet |
| `status` | Full report: stats, mood, unlocks, snacks, autostart |
| `feed` | Feed one snack |
| `test` | Simulate full start-to-complete cycle |
| `autostart [enable\|disable\|status]` | Manage login auto-start |
| `log` | View recent logs |

When checking pet status, feeding, restarting, or testing -- prefer `pet-ctl.sh` over manual curl commands.

## Common Tasks

### Start/Stop Pet

```bash
bash ~/office-pet/start.sh   # Start (background)
bash ~/office-pet/stop.sh    # Stop
```

### Check Status

```bash
curl http://127.0.0.1:13121/health
```

### Test Notifications

```bash
# Simulate task start
curl http://127.0.0.1:13121/start

# Simulate task complete
curl -X POST http://127.0.0.1:13121/notify \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","message":"Done","type":"done"}'
```

### Add New Pet Sprite

Edit `renderer/pets.js`:

1. Define pet drawing function in `renderer/pets-1.js` or `renderer/pets-2.js` using Canvas 2D API
2. Add unlock condition in `UNLOCK_CONDITIONS`
3. Add default unlock entry in `main.js` `loadUnlocks()` if free by default
4. Restart pet

### Customize Sound Effects

Sound effects synthesized via Web Audio API in `renderer/app.js`:
- `playMarioSuccessSound()`: Task completion melody
- `playChompSound()`: Feeding sound
- Modify note frequencies and timing to customize

### View Stats

```bash
curl http://127.0.0.1:13121/daily-stats        # Today's stats
curl http://127.0.0.1:13121/mood              # Mood + streak + today's conversations
curl http://127.0.0.1:13121/unlocks            # Unlocked pets
curl http://127.0.0.1:13121/total-conversations # Total conversations ever
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Port 13121 occupied | `lsof -ti :13121 \| xargs kill`, then restart |
| Hooks not firing (CodeBuddy) | Verify `~/.codebuddy/settings.json` has hooks; `chmod +x hooks/*.sh` |
| Hooks not firing (WorkBuddy) | Verify `~/.workbuddy/settings.json` has hooks; run `bash install-hooks.sh` |
| Pet not visible | Check if fullscreen app covers it; pet uses `floating` window level |
| No sound | Check macOS audio permission; check system volume |
| Pet data lost | Stats in `~/.office-pet-stats/`; unlocks in `unlocks.json` |
