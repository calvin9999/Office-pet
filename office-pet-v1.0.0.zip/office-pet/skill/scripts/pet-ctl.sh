#!/usr/bin/env bash
# Office Pet - 快捷操作脚本
# 用法: bash pet-ctl.sh <command>

PET_DIR="$(cd "$(dirname "$0")/../../../office-pet" 2>/dev/null && pwd)"
if [ -z "$PET_DIR" ] || [ ! -f "$PET_DIR/main.js" ]; then
  PET_DIR="$HOME/office-pet"
fi
PORT=13121
API="http://127.0.0.1:$PORT"

case "$1" in
  start)
    bash "$PET_DIR/start.sh"
    ;;
  stop)
    bash "$PET_DIR/stop.sh"
    ;;
  restart)
    bash "$PET_DIR/stop.sh" 2>/dev/null
    sleep 1
    bash "$PET_DIR/start.sh"
    ;;
  status)
    echo "=== 服务状态 ==="
    curl -s "$API/health" 2>/dev/null && echo "" || echo "❌ 未运行"
    echo ""
    echo "=== 今日统计 ==="
    curl -s "$API/daily-stats" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "无数据"
    echo ""
    echo "=== 宠物心情 ==="
    curl -s "$API/mood" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "无数据"
    echo ""
    echo "=== 零食余量 ==="
    curl -s "$API/feed-status" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "无数据"
    echo ""
    echo "=== 已解锁宠物 ==="
    curl -s "$API/unlocks" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "无数据"
    echo ""
    echo "=== 累计对话 ==="
    curl -s "$API/total-conversations" 2>/dev/null | python3 -m json.tool 2>/dev/null || echo "无数据"
    echo ""
    echo "=== 开机自启 ==="
    if [ -f "$HOME/Library/LaunchAgents/com.office.pet.plist" ]; then
      echo "✅ 已开启"
    else
      echo "❌ 未开启"
    fi
    ;;
  feed)
    RESULT=$(curl -s -X POST "$API/feed" -H "Content-Type: application/json" -d '{}' 2>/dev/null)
    if echo "$RESULT" | grep -q '"ok":true'; then
      echo "🍪 喂食成功！"
    else
      echo "❌ 喂食失败（可能没有零食了）"
    fi
    ;;
  autostart)
    bash "$PET_DIR/autostart.sh" "${2:-status}"
    ;;
  test)
    echo "▶ 模拟开始任务..."
    curl -s "$API/start" >/dev/null
    echo "  等待 3 秒..."
    sleep 3
    echo "✅ 模拟任务完成"
    curl -s -X POST "$API/notify" \
      -H "Content-Type: application/json" \
      -d '{"title":"Office Pet","message":"✅ 测试通知成功！","type":"done"}' >/dev/null
    echo "  请查看桌面宠物反应"
    ;;
  log)
    if [ -f "$PET_DIR/.pet.log" ]; then
      tail -50 "$PET_DIR/.pet.log"
    else
      echo "无日志文件"
    fi
    ;;
  *)
    echo "🐾 Office Pet 控制工具"
    echo ""
    echo "用法: bash pet-ctl.sh <command>"
    echo ""
    echo "  start       启动宠物"
    echo "  stop        停止宠物"
    echo "  restart     重启宠物"
    echo "  status      查看完整状态（统计/心情/解锁/零食）"
    echo "  feed        喂一个零食"
    echo "  test        模拟一次完整的 开始→完成 流程"
    echo "  autostart   管理开机自启 [enable|disable|status]"
    echo "  log         查看最近日志"
    ;;
esac
