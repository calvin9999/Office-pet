# Office Pet 详细安装指南

## 手动安装步骤

### 1. 环境要求

| 依赖 | 版本 | 检查命令 |
|------|------|----------|
| macOS | 任意版本 | `sw_vers` |
| Node.js | >= 18 | `node -v` |
| npm | >= 9 | `npm -v` |
| Python 3 | >= 3.8 | `python3 --version` |
| curl | 系统自带 | `curl --version` |

### 2. 安装步骤

```bash
cd ~
git clone <repo-url> office-pet
cd office-pet
npm install
chmod +x start.sh stop.sh hooks/*.sh
```

### 3. 配置 Hooks

编辑 `~/.codebuddy/settings.json`（如果文件不存在则创建）：

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "/Users/YOUR_USERNAME/office-pet/hooks/on_start.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Bash|execute_command",
        "hooks": [
          {
            "type": "command",
            "command": "/Users/YOUR_USERNAME/office-pet/hooks/on_tool_use.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "/Users/YOUR_USERNAME/office-pet/hooks/on_finish.sh",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
```

**将 `YOUR_USERNAME` 替换为你的 macOS 用户名。**

如果 settings.json 中已有其他配置（如 `enabledPlugins`），只需添加 `hooks` 字段，不要删除已有内容。

### 4. 启动

```bash
bash ~/office-pet/start.sh
```

### 5. 验证

```bash
# 检查服务
curl http://127.0.0.1:13121/health

# 模拟完整流程
curl http://127.0.0.1:13121/start
sleep 3
curl -X POST http://127.0.0.1:13121/notify \
  -H "Content-Type: application/json" \
  -d '{"title":"Office Pet","message":"✅ 安装成功！","type":"done"}'
```

### 6. 可选：设置开机自启

创建 macOS LaunchAgent：

```bash
cat > ~/Library/LaunchAgents/com.office.pet.plist << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.office.pet</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>$HOME/office-pet/start.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>
EOF

launchctl load ~/Library/LaunchAgents/com.office.pet.plist
```

## 卸载

```bash
# 停止宠物
bash ~/office-pet/stop.sh

# 移除 Hook 配置（编辑 settings.json 删除 hooks 部分）

# 移除项目
rm -rf ~/office-pet

# 移除数据
rm -rf ~/.office-pet-stats

# 移除开机自启（如果设置了）
launchctl unload ~/Library/LaunchAgents/com.office.pet.plist 2>/dev/null
rm -f ~/Library/LaunchAgents/com.office.pet.plist
```
