# License Server 自签证书

将服务器端生成的 `license.crt` 放到本目录下。

打包 DMG 时会自动包含此证书，客户端启动后自动加载。

## 生成方式（在 License Server 上执行）

```bash
openssl req -x509 -nodes -days 3650 \
  -newkey rsa:2048 \
  -keyout /etc/nginx/ssl/license.key \
  -out /etc/nginx/ssl/license.crt \
  -subj "/CN=123.207.44.191" \
  -addext "subjectAltName=IP:123.207.44.191"
```

然后将 `/etc/nginx/ssl/license.crt` 复制到本目录。
