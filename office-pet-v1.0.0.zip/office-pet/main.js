const { app, BrowserWindow, Tray, Menu, screen, nativeImage, ipcMain, dialog } = require('electron');
const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const license = require('./src/license');

// ── Config ───────────────────────────────────────────────────────────
const PORT = 13121;
const IDLE_WIDTH = 220;    // idle 态：pill（宠物 + T 数字）
const IDLE_HEIGHT = 100;
const TIMER_WIDTH = 220;   // 计时器状态：与 idle 同宽，保持对称
const EXPAND_WIDTH = 580;  // 通知状态：横向展开
const ACTIVE_HEIGHT = 100;  // 展开后高度（更窄）
const SHADOW_PAD = 28;
let win = null;
let tray = null;
let wss = null;
let shrinkTimer = null;
let isTimerMode = false;

// ── Daily Stats (persistent) ─────────────────────────────────────────
const STATS_DIR = path.join(require('os').homedir(), '.office-pet-stats');
if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function statsFile() {
  return path.join(STATS_DIR, `${todayKey()}.json`);
}

function loadDailyStats() {
  try {
    return JSON.parse(fs.readFileSync(statsFile(), 'utf-8'));
  } catch {
    return { conversations: 0, totalChars: 0, totalFiles: 0, editedFiles: [] };
  }
}

function saveDailyStats(stats) {
  fs.writeFileSync(statsFile(), JSON.stringify(stats), 'utf-8');
}

// ── Multi-session management ─────────────────────────────────────────
const activeSessions = new Map(); // session_id → { workspace, label, startTime, status }

function addSession(sessionId, workspace, label, description) {
  activeSessions.set(sessionId || 'default', {
    workspace: workspace || '',
    label: label || 'session',
    description: description || '',
    startTime: Date.now(),
    status: 'running', // running | waiting_approval | done
  });
  // 有新任务时记录为活跃
}

function removeSession(sessionId) {
  activeSessions.delete(sessionId || 'default');
}

function hasActiveSessions() {
  return activeSessions.size > 0;
}

function getSessionsSnapshot() {
  const now = Date.now();
  return Array.from(activeSessions.entries()).map(([id, s]) => ({
    id,
    label: s.label,
    description: s.description || '',
    elapsed: Math.floor((now - s.startTime) / 1000),
    status: s.status,
  }));
}

// ── Kill old process on same port ───────────────────────────────────
function killOldProcess() {
  try {
    const pids = execSync(`lsof -ti :${PORT} 2>/dev/null`, { encoding: 'utf-8' }).trim();
    if (pids) {
      pids.split('\n').forEach(pid => {
        try { process.kill(Number(pid), 'SIGKILL'); } catch (_) {}
      });
      // 等一下端口释放
      execSync('sleep 0.5');
      console.log(`🧹 已清理旧进程: ${pids.replace(/\n/g, ', ')}`);
    }
  } catch (_) {
    // 没有占用就忽略
  }
}

// ── Express + WebSocket Server ───────────────────────────────────────
const expApp = express();
expApp.use(express.json());
expApp.use(express.static(path.join(__dirname, 'renderer')));

const server = http.createServer(expApp);
wss = new WebSocketServer({ server, path: '/ws' });

function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === 1) client.send(msg);
  });
}

// ── API Endpoints ────────────────────────────────────────────────────
expApp.post('/notify', (req, res) => {
  const { title, message, type, session_id } = req.body;
  removeSession(session_id);

  if (!hasActiveSessions()) {
    isTimerMode = false;
  }

  const notifyData = {
    type: 'notification',
    title: title || 'Office Pet',
    message: message || '任务已完成！',
    notifyType: type || 'done',
    sessionId: session_id,
    stillWaiting: hasActiveSessions(),
    sessions: getSessionsSnapshot(),
  };
  broadcast(notifyData);
  expandWindow(notifyData.message);
  res.json({ ok: true });
});

expApp.get('/notify', (req, res) => {
  const title = req.query.title || 'Office Pet';
  const message = req.query.message || '任务已完成！';
  const type = req.query.type || 'done';
  removeSession(req.query.session_id);

  if (!hasActiveSessions()) {
    isTimerMode = false;
  }

  const notifyData = {
    type: 'notification', title, message, notifyType: type,
    sessionId: req.query.session_id,
    stillWaiting: hasActiveSessions(),
    sessions: getSessionsSnapshot(),
  };
  broadcast(notifyData);
  expandWindow(message);
  res.json({ ok: true });
});

expApp.get('/health', (req, res) => {
  res.json({ status: 'running', port: PORT });
});

// Start waiting (Office Pet task begins)
expApp.get('/start', (req, res) => {
  const sessionId = req.query.session_id || `s${Date.now()}`;
  const workspace = req.query.workspace || '';
  const label = req.query.workspace_label || '';
  const description = req.query.description || '';
  addSession(sessionId, workspace, label, description);
  const daily = loadDailyStats();
  daily.conversations = (daily.conversations || 0) + 1;
  saveDailyStats(daily);
  broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
  isTimerMode = true;
  resizeForSessions();
  res.json({ ok: true, status: 'waiting', session_id: sessionId });
});

expApp.post('/start', (req, res) => {
  const sessionId = (req.body && req.body.session_id) || `s${Date.now()}`;
  const workspace = (req.body && req.body.workspace) || '';
  const label = (req.body && req.body.workspace_label) || '';
  const description = (req.body && req.body.description) || '';
  addSession(sessionId, workspace, label, description);
  const daily = loadDailyStats();
  daily.conversations = (daily.conversations || 0) + 1;
  saveDailyStats(daily);
  broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
  isTimerMode = true;
  resizeForSessions();
  res.json({ ok: true, status: 'waiting', session_id: sessionId });
});

// Stop waiting (without notification)
expApp.get('/stop', (req, res) => {
  removeSession(req.query.session_id);
  if (!hasActiveSessions()) {
    broadcast({ type: 'sessions-update', sessions: [] });
    isTimerMode = false;
    shrinkToIdle();
  } else {
    broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
    resizeForSessions();
  }
  res.json({ ok: true, status: hasActiveSessions() ? 'waiting' : 'idle' });
});

expApp.post('/stop', (req, res) => {
  removeSession(req.body && req.body.session_id);
  if (!hasActiveSessions()) {
    broadcast({ type: 'sessions-update', sessions: [] });
    isTimerMode = false;
    shrinkToIdle();
  } else {
    broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
    resizeForSessions();
  }
  res.json({ ok: true, status: hasActiveSessions() ? 'waiting' : 'idle' });
});

// Update session status (e.g., waiting_approval)
expApp.post('/session-status', (req, res) => {
  const { session_id, status } = req.body;
  if (session_id && activeSessions.has(session_id)) {
    const s = activeSessions.get(session_id);
    s.status = status || 'running';
    broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
  }
  res.json({ ok: true });
});

// Get current sessions (for polling)
expApp.get('/sessions', (req, res) => {
  res.json({ sessions: getSessionsSnapshot() });
});

// Get daily stats (for idle display)
expApp.get('/daily-stats', (req, res) => {
  res.json(loadDailyStats());
});

// ── Mood System: returns mood based on usage history ─────────────────
expApp.get('/mood', (req, res) => {
  const today = new Date();
  let streak = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const file = path.join(STATS_DIR, `${key}.json`);
    try {
      const s = JSON.parse(fs.readFileSync(file, 'utf-8'));
      if (s.conversations > 0) streak++;
      else break;
    } catch { break; }
  }
  // mood: happy(3+days), normal(1-2days), sleepy(0 today but yesterday), sad(0 for 2+ days)
  const todayStats = loadDailyStats();
  let mood = 'normal';
  if (streak >= 3) mood = 'happy';
  else if (streak === 0 && todayStats.conversations === 0) mood = 'sad';
  else if (todayStats.conversations === 0) mood = 'sleepy';
  res.json({ mood, streak, todayConversations: todayStats.conversations });
});

// ── Feed System: track snacks ────────────────────────────────────────
expApp.post('/feed', (req, res) => {
  const daily = loadDailyStats();
  daily.snacks = (daily.snacks || 0) + 1;
  saveDailyStats(daily);
  broadcast({ type: 'feed', snacks: daily.snacks });
  res.json({ ok: true, snacks: daily.snacks });
});

expApp.get('/feed-status', (req, res) => {
  const daily = loadDailyStats();
  const snacksAvailable = (daily.conversations || 0) - (daily.snacks || 0);
  res.json({ snacksAvailable: Math.max(0, snacksAvailable), snacksUsed: daily.snacks || 0, conversations: daily.conversations || 0 });
});

// ── Unlock System: track unlocked pets ───────────────────────────────
const UNLOCK_FILE = path.join(STATS_DIR, 'unlocks.json');

function loadUnlocks() {
  try { return JSON.parse(fs.readFileSync(UNLOCK_FILE, 'utf-8')); }
  catch { return { unlockedPets: ['rex', 'amber', 'mochi'] }; }
}

function saveUnlocks(data) {
  fs.writeFileSync(UNLOCK_FILE, JSON.stringify(data), 'utf-8');
}

expApp.get('/unlocks', (req, res) => {
  res.json(loadUnlocks());
});

expApp.post('/unlock', (req, res) => {
  const { pet } = req.body;
  if (!pet) return res.json({ ok: false });
  const data = loadUnlocks();
  if (!data.unlockedPets.includes(pet)) {
    data.unlockedPets.push(pet);
    saveUnlocks(data);
    broadcast({ type: 'pet-unlocked', pet });
  }
  res.json({ ok: true, unlockedPets: data.unlockedPets });
});

// ── Total conversations across all days ──────────────────────────────
expApp.get('/total-conversations', (req, res) => {
  let total = 0;
  try {
    const files = fs.readdirSync(STATS_DIR).filter(f => f.endsWith('.json') && f !== 'unlocks.json');
    for (const f of files) {
      try {
        const s = JSON.parse(fs.readFileSync(path.join(STATS_DIR, f), 'utf-8'));
        total += (s.conversations || 0);
      } catch {}
    }
  } catch {}
  res.json({ total });
});

// ── License API ─────────────────────────────────────────────────────
expApp.get('/license', async (req, res) => {
  const auth = await license.checkAuthorization();
  res.json(auth);
});

expApp.post('/license/activate', async (req, res) => {
  const { key } = req.body;
  if (!key) return res.status(400).json({ ok: false, error: 'Missing key' });
  const result = await license.activateLicense(key);
  res.json(result);
});

expApp.get('/license/fingerprint', (req, res) => {
  res.json({ fingerprint: license.getMachineFingerprint() });
});

// ── Helper: get the screen where the pet window currently lives ──────
function getCurrentScreen() {
  if (!win) return screen.getPrimaryDisplay();
  const bounds = win.getBounds();
  return screen.getDisplayNearestPoint({ x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 });
}

// ── Window size management ──────────────────────────────────────────
let shapeTimer = null;
const SESSION_ROW_HEIGHT = 30; // height per session row in pixels
const SESSION_PANEL_WIDTH = 380; // width for session panel

function resizeForSessions() {
  if (!win) return;
  clearTimeout(shrinkTimer);
  clearTimeout(shapeTimer);
  const count = activeSessions.size;
  if (count === 0) { shrinkToIdle(); return; }

  const display = getCurrentScreen();
  const { x: sx, y: sy, width: screenW, height: screenH } = display.workArea;
  const bounds = win.getBounds();
  const w = SESSION_PANEL_WIDTH + SHADOW_PAD * 2;
  const h = ACTIVE_HEIGHT + (count > 1 ? (count - 1) * SESSION_ROW_HEIGHT : 0) + SHADOW_PAD * 2;

  // 使用用户放置的位置，或者当前位置
  let newX = lastUserPosition ? lastUserPosition.x : bounds.x;
  let newY = lastUserPosition ? lastUserPosition.y : bounds.y;

  // 确保不超出屏幕
  if (newX + w > sx + screenW) newX = sx + screenW - w - SNAP_MARGIN;
  if (newX < sx) newX = sx + SNAP_MARGIN;
  if (newY + h > sy + screenH) newY = sy + screenH - h - SNAP_MARGIN;
  if (newY < sy) newY = sy + SNAP_MARGIN;

  win.setBounds({ x: newX, y: newY, width: w, height: h }, true);
  shapeTimer = setTimeout(() => {
    if (win && win.webContents) win.webContents.send('shape-change', 'expanded');
  }, 50);
}

function expandToTimer() {
  resizeForSessions();
}

function shrinkToIdle() {
  if (!win) return;
  clearTimeout(shapeTimer);
  if (isTimerMode) {
    expandToTimer();
    return;
  }
  // Idle state: pill-shaped (short rounded rect) with daily stats
  if (win.webContents) win.webContents.send('shape-change', 'idle-pill');
  const display = getCurrentScreen();
  const { x: sx, y: sy, width: screenW, height: screenH } = display.workArea;
  const bounds = win.getBounds();
  const w = IDLE_WIDTH + SHADOW_PAD * 2;
  const h = IDLE_HEIGHT + SHADOW_PAD * 2;

  // 使用用户放置的位置，或者当前位置
  let newX = lastUserPosition ? lastUserPosition.x : bounds.x;
  let newY = lastUserPosition ? lastUserPosition.y : bounds.y;

  // 确保不超出屏幕
  if (newX + w > sx + screenW) newX = sx + screenW - w - SNAP_MARGIN;
  if (newX < sx) newX = sx + SNAP_MARGIN;
  if (newY + h > sy + screenH) newY = sy + screenH - h - SNAP_MARGIN;
  if (newY < sy) newY = sy + SNAP_MARGIN;

  setTimeout(() => {
    if (win) {
      win.setBounds({ x: newX, y: newY, width: w, height: h }, true);
      lastUserPosition = { x: newX, y: newY };
    }
  }, 400);
}

function expandWindow(message) {
  if (!win) return;
  clearTimeout(shrinkTimer);
  clearTimeout(shapeTimer);

  if (message === '__timer__') {
    expandToTimer();
    return;
  }

  // If other sessions still active, don't auto-shrink to idle — go back to timer
  const returnToTimer = hasActiveSessions();

  // 标题预估宽度（大多数通知标题如 "Office Pet" 约 70-90px）
  const estimatedTitleWidth = 85;
  const msgCharWidth = message.length > 0
    ? [...message].reduce((w, c) => w + (c.charCodeAt(0) > 127 ? 13.5 : 7.5), 0)
    : 0;
  // 气泡宽度取标题和消息中的较宽者，加 padding
  const contentWidth = Math.max(estimatedTitleWidth, msgCharWidth);
  const bubbleWidth = Math.min(Math.max(contentWidth + 40, 160), EXPAND_WIDTH - 100);
  const totalWidth = 76 + bubbleWidth + SHADOW_PAD * 2 + 16;
  const finalWidth = Math.min(Math.max(totalWidth, IDLE_WIDTH + SHADOW_PAD * 2), EXPAND_WIDTH + SHADOW_PAD * 2);

  const display = getCurrentScreen();
  const { x: sx, y: sy, width: screenW, height: screenH } = display.workArea;
  const bounds = win.getBounds();

  // 使用用户放置的位置，或者当前位置
  let baseX = lastUserPosition ? lastUserPosition.x : bounds.x;
  let newX = baseX;
  const h = ACTIVE_HEIGHT + SHADOW_PAD * 2;

  // 如果展开后会超出右边缘，向左移
  if (newX + Math.round(finalWidth) > sx + screenW) {
    newX = sx + screenW - Math.round(finalWidth) - SNAP_MARGIN;
  }
  // 如果超出左边缘
  if (newX < sx) newX = sx + SNAP_MARGIN;

  let newY = lastUserPosition ? lastUserPosition.y : bounds.y;
  if (newY + h > sy + screenH) newY = sy + screenH - h - SNAP_MARGIN;
  if (newY < sy) newY = sy + SNAP_MARGIN;

  win.setBounds({ x: newX, y: newY, width: Math.round(finalWidth), height: h }, true);

  shapeTimer = setTimeout(() => {
    if (win && win.webContents) win.webContents.send('shape-change', 'expanded');
  }, 50);

  shrinkTimer = setTimeout(() => {
    if (returnToTimer) {
      isTimerMode = true;
      resizeForSessions();
    } else {
      shrinkToIdle();
    }
  }, 8000);
}

// ── IPC: 渲染进程请求调整窗口大小 ────────────────────────────────────
ipcMain.on('request-expand', (_event, message) => {
  expandWindow(message || '');
});
ipcMain.on('request-shrink', () => {
  shrinkToIdle();
});

// ── IPC: 原生右键菜单（投食 + 设置） ─────────────────────────────────
let soundEnabled = true;

ipcMain.on('show-context-menu', (_event, data) => {
  if (!win) return;
  const daily = loadDailyStats();
  const snacksAvailable = Math.max(0, (daily.conversations || 0) - (daily.snacks || 0));

  const template = [
    {
      label: snacksAvailable > 0 ? `🍪 喂零食 (${snacksAvailable})` : '🍪 没有零食了',
      enabled: snacksAvailable > 0,
      click: () => {
        daily.snacks = (daily.snacks || 0) + 1;
        saveDailyStats(daily);
        broadcast({ type: 'feed', snacks: daily.snacks });
        if (win && win.webContents) win.webContents.send('feed-result', { ok: true });
      }
    },
    { type: 'separator' },
    {
      label: soundEnabled ? '🔊 提示音：开' : '🔇 提示音：关',
      click: () => {
        soundEnabled = !soundEnabled;
        broadcast({ type: 'sound-toggle', enabled: soundEnabled });
      }
    },
    { type: 'separator' },
    { label: `每次对话 +1 零食`, enabled: false },
  ];

  const menu = Menu.buildFromTemplate(template);
  menu.popup({ window: win });
});

// ── IPC: 主进程全局拖拽（跨屏支持） ───────────────────────────────────
let dragInterval = null;
let dragAnchor = null;
let dragHistory = [];
let lastUserPosition = null; // 记录用户拖拽后的位置（吸附后）
const SNAP_DISTANCE = 60;    // 距离边缘多少像素内触发吸附
const SNAP_MARGIN = 4;       // 吸附后距边缘的间距

// ── 边缘吸附逻辑 ─────────────────────────────────────────────────────
function snapToEdge(posX, posY, boundsW, boundsH) {
  const display = getCurrentScreen();
  const { x: sx, y: sy, width: sw, height: sh } = display.workArea;

  let targetX = posX, targetY = posY;
  let snapped = false;

  if (posX - sx < SNAP_DISTANCE) {
    targetX = sx + SNAP_MARGIN;
    snapped = true;
  } else if ((sx + sw) - (posX + boundsW) < SNAP_DISTANCE) {
    targetX = sx + sw - boundsW - SNAP_MARGIN;
    snapped = true;
  }

  if (posY - sy < SNAP_DISTANCE) {
    targetY = sy + SNAP_MARGIN;
    snapped = true;
  } else if ((sy + sh) - (posY + boundsH) < SNAP_DISTANCE) {
    targetY = sy + sh - boundsH - SNAP_MARGIN;
    snapped = true;
  }

  return { targetX, targetY, snapped };
}

function animateSnap(fromX, fromY, toX, toY, boundsW, boundsH, duration = 200) {
  if (!win) return;
  const startTime = Date.now();
  const snapInterval = setInterval(() => {
    if (!win) { clearInterval(snapInterval); return; }
    const elapsed = Date.now() - startTime;
    const t = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - t, 3);
    const cx = Math.round(fromX + (toX - fromX) * ease);
    const cy = Math.round(fromY + (toY - fromY) * ease);
    win.setBounds({ x: cx, y: cy, width: boundsW, height: boundsH });
    if (t >= 1) {
      clearInterval(snapInterval);
      lastUserPosition = { x: toX, y: toY };
    }
  }, 16);
}

ipcMain.on('start-drag', () => {
  if (!win) return;

  const cursor = screen.getCursorScreenPoint();
  const bounds = win.getBounds();
  dragAnchor = { offsetX: cursor.x - bounds.x, offsetY: cursor.y - bounds.y };
  dragHistory = [];
  clearInterval(dragInterval);
  dragInterval = setInterval(() => {
    if (!win || !dragAnchor) { clearInterval(dragInterval); return; }
    const cur = screen.getCursorScreenPoint();
    const b = win.getBounds();
    const newX = cur.x - dragAnchor.offsetX;
    const newY = cur.y - dragAnchor.offsetY;
    dragHistory.push({ x: newX, y: newY, t: Date.now() });
    if (dragHistory.length > 5) dragHistory.shift();
    if (newX !== b.x || newY !== b.y) {
      win.setBounds({ x: newX, y: newY, width: b.width, height: b.height });
    }
  }, 16);
});

ipcMain.on('stop-drag', () => {
  clearInterval(dragInterval);
  dragInterval = null;
  dragAnchor = null;

  // Calculate velocity from drag history for physics fling
  if (win && dragHistory && dragHistory.length >= 2) {
    const last = dragHistory[dragHistory.length - 1];
    const prev = dragHistory[0];
    const dt = (last.t - prev.t) / 1000;
    if (dt > 0 && dt < 0.3) {
      const vx = (last.x - prev.x) / dt;
      const vy = (last.y - prev.y) / dt;
      if (Math.abs(vx) > 100 || Math.abs(vy) > 100) {
        // Start physics animation in main process
        let posX = last.x, posY = last.y;
        let velX = vx * 0.3, velY = vy * 0.3;
        const friction = 0.92;
        const bounce = -0.6;
        const flingInterval = setInterval(() => {
          if (!win || (Math.abs(velX) < 5 && Math.abs(velY) < 5)) {
            clearInterval(flingInterval);
            // 惯性结束 → 吸附到最近边缘
            if (win) {
              const b = win.getBounds();
              const snap = snapToEdge(posX, posY, b.width, b.height);
              if (snap.snapped) {
                animateSnap(Math.round(posX), Math.round(posY), snap.targetX, snap.targetY, b.width, b.height);
              } else {
                lastUserPosition = { x: Math.round(posX), y: Math.round(posY) };
              }
            }
            return;
          }
          posX += velX * 0.016;
          posY += velY * 0.016;
          velX *= friction;
          velY *= friction;
          // Bounce off screen edges
          const display = getCurrentScreen();
          const { x: sx, y: sy, width: sw, height: sh } = display.workArea;
          const b = win.getBounds();
          if (posX < sx) { posX = sx; velX *= bounce; }
          if (posX + b.width > sx + sw) { posX = sx + sw - b.width; velX *= bounce; }
          if (posY < sy) { posY = sy; velY *= bounce; }
          if (posY + b.height > sy + sh) { posY = sy + sh - b.height; velY *= bounce; }
          win.setBounds({ x: Math.round(posX), y: Math.round(posY), width: b.width, height: b.height });
        }, 16);
        dragHistory = [];
        return; // fling handles snap, skip direct snap below
      }
    }
  }

  // 没有惯性 → 直接吸附
  if (win) {
    const b = win.getBounds();
    const snap = snapToEdge(b.x, b.y, b.width, b.height);
    if (snap.snapped) {
      animateSnap(b.x, b.y, snap.targetX, snap.targetY, b.width, b.height);
    } else {
      lastUserPosition = { x: b.x, y: b.y };
    }
  }
  dragHistory = [];
});

// ── Electron Window ──────────────────────────────────────────────────
function createWindow() {
  const { width: screenW } = screen.getPrimaryDisplay().workAreaSize;
  const initW = IDLE_WIDTH + SHADOW_PAD * 2;
  const initH = IDLE_HEIGHT + SHADOW_PAD * 2;

  win = new BrowserWindow({
    width: initW,
    height: initH,
    x: screenW - initW - SNAP_MARGIN,
    y: SNAP_MARGIN,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    resizable: false,
    movable: true,
    skipTaskbar: true,
    hasShadow: false,
    roundedCorners: false,
    backgroundColor: '#00000000',
    // macOS: 出现在所有桌面空间（Mission Control）
    visibleOnAllWorkspaces: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  // 使用 floating 级别 — 高于普通 alwaysOnTop，不会被其他窗口遮挡
  // macOS 窗口层级: normal < floating < torn-off-menu < modal-panel < main-menu < status < pop-up-menu < screen-saver
  win.setAlwaysOnTop(true, 'floating');

  // macOS: 在所有工作区（包括全屏应用的空间）都可见
  if (process.platform === 'darwin') {
    win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  }

  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.setIgnoreMouseEvents(false);

  if (process.platform === 'darwin') {
    app.dock.hide();
  }

  // 定期确保窗口保持在最前面（防止某些应用抢夺焦点）
  setInterval(() => {
    if (win && !win.isDestroyed()) {
      win.setAlwaysOnTop(true, 'floating');
    }
  }, 5000);

  // 初始位置记录
  const initBounds = win.getBounds();
  lastUserPosition = { x: initBounds.x, y: initBounds.y };

  win.on('closed', () => { win = null; });
}

// ── Tray ─────────────────────────────────────────────────────────────
function createTray() {
  const icon = nativeImage.createFromBuffer(createTrayIconBuffer(), { width: 16, height: 16 });
  tray = new Tray(icon);
  tray.setToolTip('Office Pet');

  const contextMenu = Menu.buildFromTemplate([
    { label: '🐾 Office Pet', enabled: false },
    { type: 'separator' },
    {
      label: '▶ 模拟开始任务', click: () => {
        broadcast({ type: 'start-waiting' });
        isTimerMode = true;
        expandToTimer();
      }
    },
    {
      label: '✅ 模拟任务完成', click: () => {
        if (isTimerMode) {
          broadcast({ type: 'stop-waiting' });
          isTimerMode = false;
        }
        const msg = '✅ 任务已完成！这是一条来自 Office Pet 的提醒消息~';
        broadcast({ type: 'notification', title: 'Office Pet', message: msg, notifyType: 'done' });
        expandWindow(msg);
      }
    },
    {
      label: '显示/隐藏', click: () => {
        if (win) win.isVisible() ? win.hide() : win.show();
      }
    },
    { type: 'separator' },
    { label: '退出', click: () => app.quit() }
  ]);
  tray.setContextMenu(contextMenu);
}

function createTrayIconBuffer() {
  const size = 16;
  const buf = Buffer.alloc(size * size * 4, 0);
  const pixels = [
    [5,3],[10,3],[5,4],[6,4],[9,4],[10,4],
    [6,5],[7,5],[8,5],[9,5],[6,6],[9,6],
    [7,7],[8,7],[5,8],[6,8],[7,8],[8,8],[9,8],[10,8],
    [6,9],[7,9],[8,9],[9,9],
  ];
  pixels.forEach(([x, y]) => {
    const i = (y * size + x) * 4;
    buf[i] = 255; buf[i+1] = 180; buf[i+2] = 0; buf[i+3] = 255;
  });
  return buf;
}

// ── App Lifecycle ────────────────────────────────────────────────────
app.whenReady().then(async () => {
  // ── License 授权检查 ──────────────────────────────────────────────
  const auth = await license.checkAuthorization();
  if (!auth.authorized) {
    dialog.showMessageBoxSync({
      type: 'warning',
      title: 'Office Pet - 授权已过期',
      message: '试用期已结束，请激活 License',
      detail: `机器指纹: ${auth.fingerprint}\n\n请运行以下命令获取指纹:\nbash scripts/fingerprint.sh\n\n然后联系管理员获取 License Key。`,
      buttons: ['退出'],
    });
    app.quit();
    return;
  }
  console.log(`🔑 授权状态: ${auth.reason}`);

  killOldProcess();

  server.listen(PORT, '127.0.0.1', () => {
    console.log(`🐾 Office Pet server running on http://127.0.0.1:${PORT}`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`❌ 端口 ${PORT} 仍被占用，尝试再次清理...`);
      killOldProcess();
      setTimeout(() => {
        server.listen(PORT, '127.0.0.1');
      }, 1000);
    }
  });

  createWindow();
  createTray();

  // Broadcast session timers every second
  setInterval(() => {
    if (hasActiveSessions()) {
      broadcast({ type: 'sessions-update', sessions: getSessionsSnapshot() });
    }
  }, 1000);
});

app.on('window-all-closed', () => {});

app.on('activate', () => {
  if (!win) createWindow();
});

app.on('before-quit', () => {
  server.close();
});
