#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 一键安装脚本
#  同时写入 CodeBuddy 和 WorkBuddy 双端 Hook 配置
#  用法: bash install.sh
# ──────────────────────────────────────────────

set -e

PET_DIR="$(cd "$(dirname "$0")" && pwd)"
CB_SETTINGS="$HOME/.codebuddy/settings.json"
WB_SETTINGS="$HOME/.workbuddy/settings.json"
PORT=13121

echo "Office Pet 安装程序"
echo "======================="
echo ""

# ── 检查前置要求 ─────────────────────────────
echo "📋 检查前置要求..."

if ! command -v node &>/dev/null; then
  echo "❌ 未找到 Node.js，请先安装: https://nodejs.org/"
  exit 1
fi

NODE_VER=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VER" -lt 18 ]; then
  echo "❌ Node.js 版本需要 >= 18，当前: $(node -v)"
  exit 1
fi
echo "   ✅ Node.js $(node -v)"

if ! command -v python3 &>/dev/null; then
  echo "❌ 未找到 Python 3，请先安装"
  exit 1
fi
echo "   ✅ Python 3"

if ! command -v npx &>/dev/null; then
  echo "❌ 未找到 npx，请确认 npm 已安装"
  exit 1
fi
echo "   ✅ npm/npx"

echo ""

# ── 安装依赖 ─────────────────────────────────
echo "📦 安装依赖..."
cd "$PET_DIR"
npm install --no-fund --no-audit 2>&1 | tail -1
echo "   ✅ 依赖已安装"
echo ""

# ── 设置脚本权限 ─────────────────────────────
echo "🔑 设置脚本权限..."
chmod +x "$PET_DIR/start.sh" "$PET_DIR/stop.sh" "$PET_DIR/hooks/"*.sh
echo "   ✅ 已设置执行权限"
echo ""

# ── 配置 Hooks（双端）────
echo "配置 Hooks (双端)..."

# 通用函数：向指定 settings 文件写入/合并 hooks
merge_hooks() {
  local SETTINGS_FILE="$1"
  local DIRNAME="$(dirname "$SETTINGS_FILE")"

  mkdir -p "$DIRNAME"

  if [ ! -f "$SETTINGS_FILE" ]; then
    # 全新创建
    cat > "$SETTINGS_FILE" << ENDJSON
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_start.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_tool_use.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_tool_done.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_finish.sh",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
ENDJSON
    echo "   已创建 $SETTINGS_FILE"
  else
    # 已有配置，检查是否已包含 hooks
    if python3 -c "
import json, sys
with open('$SETTINGS_FILE') as f:
    d = json.load(f)
if 'hooks' in d and 'Stop' in d.get('hooks', {}):
    sys.exit(0)
sys.exit(1)
" 2>/dev/null; then
      echo "   $SETTINGS_FILE 已有 hooks，跳过"
    else
      python3 -c "
import json
with open('$SETTINGS_FILE') as f:
    d = json.load(f)
d.setdefault('hooks', {})
pet_dir = '$PET_DIR'
d['hooks']['UserPromptSubmit'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_start.sh', 'timeout': 5}]}]
d['hooks']['PreToolUse'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_tool_use.sh', 'timeout': 5}]}]
d['hooks']['PostToolUse'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_tool_done.sh', 'timeout': 5}]}]
d['hooks']['Stop'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_finish.sh', 'timeout': 5}]}]
with open('$SETTINGS_FILE', 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
" 2>/dev/null
      echo "   已合并 hooks 到 $SETTINGS_FILE"
    fi
  fi
}

merge_hooks "$CB_SETTINGS"   # CodeBuddy
merge_hooks "$WB_SETTINGS"   # WorkBuddy
echo ""

# ── 安装 Skill ───────────────────────────────
echo "🧠 安装 Office Pet Skill..."
SKILL_SRC="$PET_DIR/skill"
SKILL_DST="$HOME/.codebuddy/skills/office-pet"

if [ -d "$SKILL_SRC" ]; then
  mkdir -p "$HOME/.codebuddy/skills"
  if [ -d "$SKILL_DST" ]; then
    rm -rf "$SKILL_DST"
  fi
  cp -r "$SKILL_SRC" "$SKILL_DST"
  chmod +x "$SKILL_DST/scripts/"*.sh 2>/dev/null
  echo "   ✅ Skill 已安装到 $SKILL_DST"
else
  echo "   ⚠️  未找到 skill 目录，跳过"
fi
echo ""

# ── 配置开机自启 ─────────────────────────────
echo "⚡ 配置开机自启..."
bash "$PET_DIR/autostart.sh" enable
echo ""

# ── 启动宠物 ─────────────────────────────────
echo "🚀 启动 Office Pet..."
bash "$PET_DIR/start.sh"

echo ""
echo "=========================================="
echo "安装完成！"
echo ""
echo "   宠物已在屏幕右上角出现"
echo "   已配置开机自启，重启后无需手动启动"
echo "   Hooks 已写入 CodeBuddy 和 WorkBuddy 双端"
echo "   在任一客户端中对话即可触发宠物"
echo ""
echo "   停止宠物: bash $PET_DIR/stop.sh"
echo "   重新启动: bash $PET_DIR/start.sh"
echo "   关闭自启: bash $PET_DIR/autostart.sh disable"
echo "=========================================="
