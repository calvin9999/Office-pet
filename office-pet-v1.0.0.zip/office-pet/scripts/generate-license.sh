#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - License 生成工具（管理员专用）
#
#  根据用户提供的机器指纹生成 License Key。
#
#  用法: bash scripts/generate-license.sh <fingerprint>
#  示例: bash scripts/generate-license.sh A1B2-C3D4-E5F6-7890
# ──────────────────────────────────────────────

FINGERPRINT="$1"

if [ -z "$FINGERPRINT" ]; then
  echo "❌ 请提供机器指纹"
  echo "   用法: bash scripts/generate-license.sh <fingerprint>"
  echo "   示例: bash scripts/generate-license.sh A1B2-C3D4-E5F6-7890"
  exit 1
fi

ISSUED_AT=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
SECRET="office-pet-license-v1"
PAYLOAD="${FINGERPRINT}|${ISSUED_AT}"

# HMAC-SHA256 签名，取前 32 位大写
KEY=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "$SECRET" | awk '{print $NF}' | cut -c1-32 | tr 'a-f' 'A-F')

echo ""
echo "🔑 License 已生成"
echo "=================="
echo ""
echo "   指纹:      $FINGERPRINT"
echo "   签发时间:  $ISSUED_AT"
echo "   License:   $KEY"
echo ""
echo "   用户激活命令："
echo ""
echo "   curl -X POST http://127.0.0.1:13121/license/activate \\"
echo "     -H 'Content-Type: application/json' \\"
echo "     -d '{\"key\": \"$KEY\", \"fingerprint\": \"$FINGERPRINT\", \"issuedAt\": \"$ISSUED_AT\", \"expiresAt\": null}'"
echo ""

# 生成完整 JSON 供直接写入
echo "   或直接写入文件："
echo ""
echo "   echo '{\"key\":\"$KEY\",\"fingerprint\":\"$FINGERPRINT\",\"issuedAt\":\"$ISSUED_AT\",\"expiresAt\":null}' > ~/.office-pet-stats/license.json"
echo ""
