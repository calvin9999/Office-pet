#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 机器指纹获取脚本
#
#  运行此脚本获取当前机器的唯一指纹，
#  将指纹提交到授权平台获取 License Key。
#
#  用法: bash scripts/fingerprint.sh
# ──────────────────────────────────────────────

echo ""
echo "🔑 Office Pet 机器指纹"
echo "======================"
echo ""

# 采集硬件信息
SERIAL=$(ioreg -l 2>/dev/null | grep IOPlatformSerialNumber | awk -F'"' '{print $4}')
MAC=$(ifconfig en0 2>/dev/null | awk '/ether/{print $2}')
USER=$(whoami)
HOST=$(hostname)

RAW="${SERIAL}|${MAC}|${USER}|${HOST}"
HASH=$(echo -n "$RAW" | shasum -a 256 | awk '{print $1}')
SHORT=$(echo "$HASH" | cut -c1-16 | tr 'a-f' 'A-F')

FINGERPRINT="${SHORT:0:4}-${SHORT:4:4}-${SHORT:8:4}-${SHORT:12:4}"

echo "   指纹: $FINGERPRINT"
echo ""
echo "   请将此指纹提交到授权平台获取 License Key。"
echo "   获取 License 后，运行以下命令激活："
echo ""
echo "   curl -X POST http://127.0.0.1:13121/license/activate \\"
echo "     -H 'Content-Type: application/json' \\"
echo "     -d '{\"key\": \"YOUR_LICENSE_KEY\"}'"
echo ""

# 也输出到剪贴板（macOS）
echo -n "$FINGERPRINT" | pbcopy 2>/dev/null && echo "   ✅ 指纹已复制到剪贴板" || true
echo ""
