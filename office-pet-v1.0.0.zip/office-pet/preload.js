const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  requestExpand: (message) => ipcRenderer.send('request-expand', message),
  requestShrink: () => ipcRenderer.send('request-shrink'),
  showContextMenu: (data) => ipcRenderer.send('show-context-menu', data),
  onFeedResult: (callback) => ipcRenderer.on('feed-result', (_event, result) => callback(result)),
  onShapeChange: (callback) => ipcRenderer.on('shape-change', (_event, shape) => callback(shape)),
  startDrag: () => ipcRenderer.send('start-drag'),
  stopDrag: () => ipcRenderer.send('stop-drag'),
});
