#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 开机自启配置脚本
# ──────────────────────────────────────────────

PET_DIR="$(cd "$(dirname "$0")" && pwd)"
PLIST_FILE="$HOME/Library/LaunchAgents/com.office.pet.plist"
LABEL="com.office.pet"

case "$1" in
  enable|"")
    mkdir -p "$HOME/Library/LaunchAgents"

    cat > "$PLIST_FILE" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$LABEL</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>-l</string>
        <string>$PET_DIR/start.sh</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    </dict>
    <key>StandardOutPath</key>
    <string>$PET_DIR/.pet-launch.log</string>
    <key>StandardErrorPath</key>
    <string>$PET_DIR/.pet-launch.log</string>
</dict>
</plist>
EOF

    # 先卸载旧的（如果有）
    launchctl unload "$PLIST_FILE" 2>/dev/null
    launchctl load "$PLIST_FILE"

    echo "✅ 开机自启已开启"
    echo "   配置文件: $PLIST_FILE"
    echo "   下次开机后 Office Pet 会自动启动"
    echo ""
    echo "   关闭自启: bash $PET_DIR/autostart.sh disable"
    ;;

  disable)
    if [ -f "$PLIST_FILE" ]; then
      launchctl unload "$PLIST_FILE" 2>/dev/null
      rm -f "$PLIST_FILE"
      echo "✅ 开机自启已关闭"
    else
      echo "ℹ️  未配置开机自启，无需操作"
    fi
    ;;

  status)
    if [ -f "$PLIST_FILE" ]; then
      echo "✅ 开机自启: 已开启"
      echo "   配置文件: $PLIST_FILE"
    else
      echo "❌ 开机自启: 未开启"
      echo "   开启命令: bash $PET_DIR/autostart.sh enable"
    fi
    ;;

  *)
    echo "用法: bash autostart.sh [enable|disable|status]"
    ;;
esac
