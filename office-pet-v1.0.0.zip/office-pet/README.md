# Office Pet

macOS 桌面宠物，通过 Hook 机制与 CodeBuddy / WorkBuddy 客户端深度集成。AI 对话期间宠物显示实时计时与状态，任务完成时触发弹跳通知和马里奥金币音效。支持多会话并发追踪、触摸互动、投食养成。

## 功能

### 核心能力

- **多 Session 仪表盘** -- 同时追踪多个对话，显示工作区名、耗时、运行状态（running / waiting_approval / done）
- **等待授权提示** -- AI 等待用户确认操作时，宠物切换为橙色暂停图标
- **任务完成通知** -- 弹跳动画 + 粒子特效 + 随机文案 + 马里奥金币音效
- **危险命令检测** -- AI 执行高危命令时发出红色警告

### 交互系统

- **触摸反馈** -- 单击：爱心飘出 + 挤压变形
- **投食** -- 右键喂零食：食物飞入嘴中 + 电子咀嚼音（每完成一次对话 +1 零食）
- **心情系统** -- 根据连续使用天数递减：happy -> neutral -> sleepy -> sad
- **宠物收集** -- 10 只 Furry 风格宠物，Canvas 2D 实时渲染，达成条件自动解锁
- **物理拖拽** -- 松手后惯性弹跳，碰屏幕边缘反弹

### 视觉与体验

- Dynamic Island 风格悬浮药丸（macOS 顶部）
- 右键菜单：喂零食 / 提示音开关
- 开机自启（LaunchAgent）

## 快速开始

### 前置要求

- macOS 12+
- Node.js >= 18
- CodeBuddy 或 WorkBuddy 客户端已安装

### 一键安装（本地 Mac）

```bash
git clone git@git.woa.com:huaixinjin/office-pet.git ~/office-pet
cd ~/office-pet
bash install.sh
```

`install.sh` 自动完成：依赖安装 -> 双端 Hook 配置 -> Skill 部署 -> 开机自启注册 -> 启动宠物。

### 云研发环境（仅安装 Hook）

云端执行：

```bash
git clone git@git.woa.com:huaixinjin/office-pet.git ~/office-pet
bash ~/office-pet/install-hooks.sh
```

仅写入 Hook 配置，无需安装 Electron 和 npm 依赖。Pet 需在本地 Mac 上运行。

## 兼容性：WorkBuddy + CodeBuddy

Pet 的安装脚本会将 Hook 配置同时写入两个客户端的配置文件：

| 客户端 | 配置路径 |
|--------|---------|
| CodeBuddy | `~/.codebuddy/settings.json` |
| WorkBuddy | `~/.workbuddy/settings.json` |

两个客户端共享同一套 Hook 脚本（位于 `~/office-pet/hooks/`），指向同一本地 Pet 服务（`127.0.0.1:13121`）。无论使用哪个客户端对话，Pet 都能正常响应。

如果之前只在 CodeBuddy 上安装过 Pet，需要在 WorkBuddy 上补配 Hook：

```bash
bash ~/office-pet/install-hooks.sh
```

该脚本自动检测并合并配置到两端。

## 操作方式

| 操作 | 效果 |
|------|------|
| 单击宠物 | 触摸反馈（爱心 + 挤压动画） |
| 双击宠物 | 切换到下一个已解锁的宠物 |
| 右键宠物 | 喂零食 / 提示音开关 |
| 拖拽 | 移动药丸，松手后物理惯性弹跳 |
| 鼠标悬停 | 显示心情状态 |

## 宠物图鉴（10 只）

| 宠物 | 稀有度 | 说明 |
|------|--------|------|
| Rex · 电狼 | UR | 赛博朋克机械狼，霓虹蓝瞳 |
| Amber · 狐娘 | SSR | 琥珀色狐狸，蓬松大尾巴 |
| Mochi · 橘座 | SSR | 奶油色小猫，圆滚滚治愈系 |
| Luna · 月兔 | SR | 薰衣草色月兔，星光眼眸 |
| Midnight · 夜豹 | UR | 暗影黑猫，绿宝石之眼 |
| Cinna · 龙崽 | UR | Q 版小火龙，肉桂色鳞片 |
| Biscuit · 二哈 | SR | 金色小柴犬，永远在微笑 |
| Honey · 小熊 | SR | 蜂蜜熊，暖棕色毛发 |
| Skye · 鹰狮 | SSR | 天蓝色小鹰，翅膀微展 |
| Clover · 精灵鹿 | SR | 三叶草绿小鹿，森林系精灵 |

## 常用命令

```bash
bash ~/office-pet/start.sh                # 启动
bash ~/office-pet/stop.sh                  # 停止
bash ~/office-pet/restart.sh               # 重启
bash ~/office-pet/autostart.sh enable      # 开机自启
bash ~/office-pet/autostart.sh disable     # 关闭自启
bash ~/office-pet/autostart.sh status      # 自启状态查询
```

通过 HTTP 接口查看状态：

```bash
curl http://127.0.0.1:13121/health            # 运行状态
curl http://127.0.0.1:13121/mood              # 心情 + 连续天数 + 今日对话数
curl http://127.0.0.1:13121/daily-stats        # 今日统计（对话数、编辑文件、零食数等）
curl http://127.0.0.1:13121/sessions           # 当前活跃 Session 列表
curl http://127.0.0.1:13121/unlocks            # 已解锁宠物列表
curl http://127.0.0.1:13121/total-conversations # 累计总对话数
```

## License 授权

Office Pet 安装后自动享有 **7 天免费试用**，第 8 天起需要有效 License 才能启动。

### 获取机器指纹

```bash
bash scripts/fingerprint.sh
```

指纹格式：`XXXX-XXXX-XXXX-XXXX`（自动复制到剪贴板）

### 激活 License

将指纹提交给管理员，获取 License Key 后：

```bash
curl -X POST http://127.0.0.1:13121/license/activate \
  -H 'Content-Type: application/json' \
  -d '{"key": "YOUR_KEY", "fingerprint": "YOUR_FINGERPRINT", "issuedAt": "ISSUED_TIME"}'
```

### 查看授权状态

```bash
curl http://127.0.0.1:13121/license
```

### 管理员生成 License

```bash
bash scripts/generate-license.sh <fingerprint>
```

## 项目结构

```
office-pet/
|-- main.js                 # Electron 主进程 + Express HTTP (端口 13121) + WebSocket
|-- preload.js              # Electron 安全上下文桥接
|-- package.json            # 依赖声明 + 构建配置
|-- src/
|   |-- license.js          # License 授权模块（指纹、试用期、密钥校验）
|-- renderer/
|   |-- index.html          # 页面骨架
|   |-- style.css           # 样式、状态图标动画、Session 面板、投食动画
|   |-- pets.js             # 10 只 Furry 宠物 Canvas 2D 渲染架构 + 解锁条件
|   |-- app.js              # 核心逻辑（多 Session 管理、交互事件、Web Audio 音效、心情系统、投食）
|-- hooks/
|   |-- on_start.sh         # UserPromptSubmit -> 启动计时，传递 session_id 与工作区名
|   |-- on_finish.sh        # Stop -> 完成通知 + 随机趣味文案
|   |-- on_tool_use.sh      # PreToolUse -> 标记 waiting_approval + 危险命令检测
|   |-- on_tool_done.sh     # PostToolUse -> 恢复 running 状态
|   |-- on_response.sh      # 回复字数统计
|   |-- on_edit.sh          # 文件编辑统计
|-- scripts/
|   |-- fingerprint.sh      # 获取机器指纹（用于 License 激活）
|   |-- generate-license.sh # License 生成工具（管理员专用）
|-- skill/                  # Skill 定义（安装时自动部署到 ~/.codebuddy/skills/）
|-- install.sh              # 本地全量安装（依赖 + Hook 双写 + Skill + 自启 + 启动）
|-- install-hooks.sh        # 轻量安装（仅写入双端 Hook 配置）
|-- setup.sh                # DMG 打包构建脚本
|-- autostart.sh            # LaunchAgent 开机自启管理
|-- start.sh / stop.sh      # 启停控制脚本
```

## Hook 事件映射

| Hook 事件 | 脚本 | 动作 |
|-----------|------|------|
| UserPromptSubmit | on_start.sh | 创建 Session，开始计时 |
| PreToolUse | on_tool_use.sh | 标记等待授权；匹配危险命令列表则红色警告 |
| PostToolUse | on_tool_done.sh | 恢复 running 状态 |
| Stop | on_finish.sh | 结束计时，弹通知 + 播放完成音效 |

Hook 脚本通过 `curl` 向 `http://127.0.0.1:13121` 发送 POST 请求，Pet 主进程接收后通过 WebSocket 推送到渲染层更新 UI。

## 故障排查

| 问题 | 解决方案 |
|------|---------|
| 端口 13121 被占用 | `lsof -ti :13121 \| xargs kill`，然后重启 |
| Hook 不生效（CodeBuddy） | 检查 `~/.codebuddy/settings.json` 中 hooks 路径是否正确，确认 `chmod +x hooks/*.sh` |
| Hook 不生效（WorkBuddy） | 检查 `~/.workbuddy/settings.json` 是否包含 hooks 字段，运行 `bash install-hooks.sh` 补配 |
| Pet 窗口不可见 | 可能被全屏应用遮挡；Pet 使用 floating 窗口层级，检查是否被其他顶层窗口覆盖 |
| 无声音 | 检查 macOS 系统音量与 Electron 音频权限 |
| 开机未自启 | `bash autostart.sh enable` 重新注册 LaunchAgent |

## 致谢

宠物设计灵感来源于 [Claude Buddy](https://github.com/handsome-rich/claude-buddy) by handsome-rich。
