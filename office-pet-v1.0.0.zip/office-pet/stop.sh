#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - 停止脚本
# ──────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/.pet.pid"
PORT=13121

# 先通过端口查找并杀掉所有占用进程（最可靠）
PORT_PIDS=$(lsof -ti :$PORT 2>/dev/null)
if [ -n "$PORT_PIDS" ]; then
  echo "🛑 正在停止 Office Pet (端口 $PORT 进程: $(echo $PORT_PIDS | tr '\n' ' '))..."
  echo "$PORT_PIDS" | xargs kill 2>/dev/null
  sleep 2
  # 检查是否还活着
  STILL_ALIVE=$(lsof -ti :$PORT 2>/dev/null)
  if [ -n "$STILL_ALIVE" ]; then
    echo "⚠️  强制终止残留进程..."
    echo "$STILL_ALIVE" | xargs kill -9 2>/dev/null
    sleep 1
  fi
fi

# 清理 PID 文件
rm -f "$PID_FILE"

# 再杀掉可能残留的 electron office-pet 进程
pkill -f "electron.*office-pet" 2>/dev/null

echo "✅ Office Pet 已停止"
