#!/bin/bash
# ──────────────────────────────────────────────
#  Office Pet - Hook 安装脚本（轻量版）
#  双端写入 Hook 配置
#
#  用法:
#    bash install-hooks.sh                    # 交互式，提示输入 Mac IP
#    bash install-hooks.sh 21.214.211.12      # 直接指定 Mac IP
# ──────────────────────────────────────────────

PET_DIR="$(cd "$(dirname "$0")" && pwd)"
CB_SETTINGS="$HOME/.codebuddy/settings.json"
WB_SETTINGS="$HOME/.workbuddy/settings.json"
PET_HOST_FILE="$PET_DIR/.pet-host"

echo "Office Pet - Hook 安装"
echo "=========================="
echo ""

# ── 获取本地 Mac 的 IP ──────────────────────
PET_HOST="${1:-}"

if [ -z "$PET_HOST" ]; then
  if [ -n "$SSH_CONNECTION" ]; then
    DETECTED_IP=$(echo "$SSH_CONNECTION" | awk '{print $1}')
    echo "检测到你的 Mac IP: $DETECTED_IP (来自 SSH 连接)"
    read -p "   使用此地址? [Y/n] " CONFIRM
    if [ "$CONFIRM" != "n" ] && [ "$CONFIRM" != "N" ]; then
      PET_HOST="$DETECTED_IP"
    fi
  fi
fi

if [ -z "$PET_HOST" ]; then
  read -p "请输入你本地 Mac 的 IP 地址: " PET_HOST
fi

if [ -z "$PET_HOST" ]; then
  echo "未提供 Mac IP，退出"
  exit 1
fi

echo "$PET_HOST" > "$PET_HOST_FILE"
echo "   宠物地址: $PET_HOST:13121"
echo ""

# ── 设置脚本权限 ─────────────────────────────
echo "设置脚本权限..."
chmod +x "$PET_DIR/hooks/"*.sh
echo "   完成"
echo ""

# ── 通用函数：向指定 settings 文件写入/合并 hooks
merge_hooks() {
  local SETTINGS_FILE="$1"
  local DIRNAME="$(dirname "$SETTINGS_FILE")"

  mkdir -p "$DIRNAME"

  if [ ! -f "$SETTINGS_FILE" ]; then
    cat > "$SETTINGS_FILE" << ENDJSON
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_start.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_tool_use.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_tool_done.sh",
            "timeout": 5
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "$PET_DIR/hooks/on_finish.sh",
            "timeout": 5
          }
        ]
      }
    ]
  }
}
ENDJSON
    echo "   已创建 $SETTINGS_FILE"
  else
    if python3 -c "
import json, sys
with open('$SETTINGS_FILE') as f:
    d = json.load(f)
if 'hooks' in d and 'Stop' in d.get('hooks', {}):
    sys.exit(0)
sys.exit(1)
" 2>/dev/null; then
      echo "   $SETTINGS_FILE 已有 hooks，跳过"
    else
      python3 -c "
import json
with open('$SETTINGS_FILE') as f:
    d = json.load(f)
d.setdefault('hooks', {})
pet_dir = '$PET_DIR'
d['hooks']['UserPromptSubmit'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_start.sh', 'timeout': 5}]}]
d['hooks']['PreToolUse'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_tool_use.sh', 'timeout': 5}]}]
d['hooks']['PostToolUse'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_tool_done.sh', 'timeout': 5}]}]
d['hooks']['Stop'] = [{'matcher': '', 'hooks': [{'type': 'command', 'command': f'{pet_dir}/hooks/on_finish.sh', 'timeout': 5}]}]
with open('$SETTINGS_FILE', 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
" 2>/dev/null
      echo "   已合并 hooks 到 $SETTINGS_FILE"
    fi
  fi
}

# ── 配置 Hooks（双端）────────────────────────
echo "配置 Hooks (双端)..."
merge_hooks "$CB_SETTINGS"   # CodeBuddy
merge_hooks "$WB_SETTINGS"   # WorkBuddy
echo ""

# ── 验证连接 ─────────────────────────────────
echo "验证连接..."
RESULT=$(curl -s --max-time 3 "http://${PET_HOST}:13121/health" 2>/dev/null)
if echo "$RESULT" | grep -q '"running"'; then
  echo "   连接成功！宠物服务可达"
else
  echo "   暂时无法连接到 $PET_HOST:13121"
  echo "   请确认本地 Mac 上宠物已启动"
fi

echo ""
echo "=========================================="
echo "Hook 安装完成！"
echo ""
echo "   宠物地址: $PET_HOST:13121"
echo "   Hooks 已写入 CodeBuddy 和 WorkBuddy 双端"
echo "   在任一客户端中对话即可触发本地宠物"
echo "=========================================="
