/**
 * Office Pet - License 授权模块（在线校验版）
 *
 * 授权流程：
 * 1. 首次安装自动记录安装时间，享有 7 天免费试用（本地 + 服务端双重记录）
 * 2. 第 8 天起需要有效 License 才能启动
 * 3. 用户运行 `scripts/fingerprint.sh` 获取机器指纹
 * 4. 管理员通过 License Server 颁发 License Key
 * 5. 用户通过 API 或手动写入激活 License
 * 6. 启动时向 License Server 在线校验；每 4 小时心跳续验
 * 7. 离线时可降级为本地缓存校验（缓存有效期 72 小时）
 *
 * 安全设计：
 * - 客户端不持有任何签名密钥
 * - License Key 由服务端生成（crypto.randomBytes），无法本地伪造
 * - 校验逻辑在服务端完成，客户端只接收 valid/invalid 结果
 * - 服务端可随时吊销 License，下次客户端校验即失效
 * - 离线缓存 72 小时后强制要求在线校验
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const { execSync } = require('child_process');

const STATS_DIR = path.join(os.homedir(), '.office-pet-stats');
const LICENSE_FILE = path.join(STATS_DIR, 'license.json');
const CACHE_FILE = path.join(STATS_DIR, '.license-cache.json');
const META_FILE = path.join(STATS_DIR, '.install-meta.json');
const TRIAL_DAYS = 7;
const HEARTBEAT_INTERVAL = 4 * 60 * 60 * 1000; // 4 小时
const OFFLINE_GRACE_HOURS = 72; // 离线宽限 72 小时

// License Server 地址（可通过环境变量覆盖）
// 默认使用 HTTPS + 自签证书；本地开发可设为 http://127.0.0.1:13122
const LICENSE_SERVER = process.env.LICENSE_SERVER || 'https://123.207.44.191';

// ── 自签证书 CA 加载 ─────────────────────────────────────────────────
// 证书文件查找顺序：
//   1. 环境变量 LICENSE_CA_CERT 指定的路径
//   2. 应用根目录下的 certs/license.crt（打包后随 app 分发）
//   3. ~/.office-pet-stats/license.crt（手动放置）
let _caCert = null;
function getCA() {
  if (_caCert !== null) return _caCert;
  const candidates = [
    process.env.LICENSE_CA_CERT,
    path.join(__dirname, '..', 'certs', 'license.crt'),
    path.join(STATS_DIR, 'license.crt'),
  ].filter(Boolean);
  for (const p of candidates) {
    try {
      _caCert = fs.readFileSync(p);
      console.log(`🔒 已加载 License CA 证书: ${p}`);
      return _caCert;
    } catch (_) {}
  }
  _caCert = false; // 没找到，标记为已尝试
  return _caCert;
}

// 根据 URL 协议自动选择 http/https，HTTPS 时附带自签 CA
function getRequestModule(url) {
  if (url.protocol === 'https:') {
    const ca = getCA();
    const agent = ca
      ? new https.Agent({ ca })
      : new https.Agent({ rejectUnauthorized: false }); // 没证书时降级（仅开发用）
    return { mod: https, agent };
  }
  return { mod: http, agent: undefined };
}

// ── 机器指纹 ────────────────────────────────────────────────────────
function getMachineFingerprint() {
  const parts = [];
  try {
    const serial = execSync(
      "ioreg -l | grep IOPlatformSerialNumber | awk -F'\"' '{print $4}'",
      { encoding: 'utf-8', timeout: 5000 }
    ).trim();
    if (serial) parts.push(serial);
  } catch (_) {}
  try {
    const mac = execSync("ifconfig en0 | awk '/ether/{print $2}'", { encoding: 'utf-8', timeout: 5000 }).trim();
    if (mac) parts.push(mac);
  } catch (_) {}
  parts.push(os.userInfo().username || 'unknown');
  parts.push(os.hostname() || 'unknown');

  const hash = crypto.createHash('sha256').update(parts.join('|')).digest('hex');
  const short = hash.substring(0, 16).toUpperCase();
  return `${short.slice(0, 4)}-${short.slice(4, 8)}-${short.slice(8, 12)}-${short.slice(12, 16)}`;
}

// ── 安装日期 ────────────────────────────────────────────────────────
function getInstallDate() {
  try {
    const meta = JSON.parse(fs.readFileSync(META_FILE, 'utf-8'));
    return new Date(meta.installDate);
  } catch (_) {
    const now = new Date();
    if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
    fs.writeFileSync(META_FILE, JSON.stringify({
      installDate: now.toISOString(),
      fingerprint: getMachineFingerprint(),
    }), 'utf-8');
    return now;
  }
}

function getTrialDaysLeft() {
  const elapsed = Math.floor((new Date() - getInstallDate()) / (1000 * 60 * 60 * 24));
  return Math.max(0, TRIAL_DAYS - elapsed);
}

function isInTrialPeriod() {
  return getTrialDaysLeft() > 0;
}

// ── 本地 License 读写 ──────────────────────────────────────────────
function loadLicense() {
  try { return JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf-8')); }
  catch (_) { return null; }
}

function saveLicense(data) {
  if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
  fs.writeFileSync(LICENSE_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// ── 离线缓存 ────────────────────────────────────────────────────────
function loadCache() {
  try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8')); }
  catch (_) { return null; }
}

function saveCache(data) {
  if (!fs.existsSync(STATS_DIR)) fs.mkdirSync(STATS_DIR, { recursive: true });
  fs.writeFileSync(CACHE_FILE, JSON.stringify({ ...data, cachedAt: new Date().toISOString() }), 'utf-8');
}

function isCacheValid() {
  const cache = loadCache();
  if (!cache || !cache.valid || !cache.cachedAt) return false;
  const age = (new Date() - new Date(cache.cachedAt)) / (1000 * 60 * 60);
  return age < OFFLINE_GRACE_HOURS;
}

// ── HTTP/HTTPS 请求封装（自动识别协议，HTTPS 时附带自签 CA）────────
function httpPost(urlPath, body, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const url = new URL(LICENSE_SERVER + urlPath);
    const { mod, agent } = getRequestModule(url);
    const payload = JSON.stringify(body);
    const req = mod.request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname,
      method: 'POST',
      timeout,
      agent,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON response')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(payload);
    req.end();
  });
}

function httpGet(urlPath, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const url = new URL(LICENSE_SERVER + urlPath);
    const { mod, agent } = getRequestModule(url);
    const req = mod.request({
      hostname: url.hostname,
      port: url.port || (url.protocol === 'https:' ? 443 : 80),
      path: url.pathname + url.search,
      method: 'GET',
      timeout,
      agent,
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
    req.end();
  });
}

// ── 在线校验 ────────────────────────────────────────────────────────
async function verifyOnline(key, fingerprint) {
  try {
    const result = await httpPost('/api/verify', { key, fingerprint });
    // 缓存校验结果
    saveCache(result);
    return result;
  } catch (err) {
    // 在线校验失败 → 降级到离线缓存
    console.warn(`⚠️ License 在线校验失败: ${err.message}，使用离线缓存`);
    if (isCacheValid()) {
      return { valid: true, reason: '离线模式（缓存有效）', offline: true };
    }
    return { valid: false, reason: `无法连接授权服务器，且离线缓存已过期（${OFFLINE_GRACE_HOURS}h）` };
  }
}

// ── 心跳续验 ────────────────────────────────────────────────────────
let heartbeatTimer = null;

function startHeartbeat(key, fingerprint) {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(async () => {
    try {
      const result = await httpPost('/api/heartbeat', {
        key,
        fingerprint,
        deviceInfo: { hostname: os.hostname(), platform: os.platform(), arch: os.arch() },
      });
      if (result.valid) {
        saveCache({ valid: true, reason: 'heartbeat ok' });
      } else {
        console.warn('⚠️ License 心跳校验失败，可能已被吊销');
      }
    } catch (_) {
      // 心跳失败不影响当前运行，但不更新缓存
    }
  }, HEARTBEAT_INTERVAL);
}

function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

// ── 综合授权检查（主入口） ──────────────────────────────────────────
async function checkAuthorization() {
  const fingerprint = getMachineFingerprint();
  const trialDaysLeft = getTrialDaysLeft();
  const license = loadLicense();

  // 1. 有 License → 在线校验
  if (license && license.key) {
    const result = await verifyOnline(license.key, fingerprint);
    if (result.valid) {
      startHeartbeat(license.key, fingerprint);
      return { authorized: true, reason: `已授权：${result.reason}`, trialDaysLeft, fingerprint };
    }
    // License 无效，但可能还在试用期
  }

  // 2. 试用期检查（先尝试在线查询，失败则用本地）
  let serverTrialDays = trialDaysLeft;
  try {
    const trialResult = await httpGet(`/api/trial?fingerprint=${fingerprint}`);
    if (trialResult.hasLicense) {
      // 服务端说有有效 license（可能本地文件丢失）
      return { authorized: true, reason: '服务端确认已授权', trialDaysLeft: 0, fingerprint };
    }
    serverTrialDays = trialResult.trialDaysLeft ?? trialDaysLeft;
  } catch (_) {
    // 服务器不可达，用本地计算
  }

  // [TEST] 注释掉试用期放行，用于测试授权过期弹窗
  // if (serverTrialDays > 0) {
  //   return { authorized: true, reason: `试用期（剩余 ${serverTrialDays} 天）`, trialDaysLeft: serverTrialDays, fingerprint };
  // }

  // 3. 既无有效 License，试用期也过了
  return { authorized: false, reason: '试用期已结束，请激活 License', trialDaysLeft: 0, fingerprint };
}

// ── 激活 License ────────────────────────────────────────────────────
async function activateLicense(key) {
  const fingerprint = getMachineFingerprint();

  // 先在线验证这个 key 是否有效
  try {
    const result = await httpPost('/api/verify', { key, fingerprint });
    if (result.valid) {
      saveLicense({ key, fingerprint, activatedAt: new Date().toISOString() });
      saveCache(result);
      startHeartbeat(key, fingerprint);
      return { ok: true, ...result };
    }
    return { ok: false, ...result };
  } catch (err) {
    return { ok: false, valid: false, reason: `无法连接授权服务器: ${err.message}` };
  }
}

module.exports = {
  getMachineFingerprint,
  getInstallDate,
  getTrialDaysLeft,
  isInTrialPeriod,
  loadLicense,
  checkAuthorization,
  activateLicense,
  startHeartbeat,
  stopHeartbeat,
  LICENSE_FILE,
  STATS_DIR,
  LICENSE_SERVER,
};
